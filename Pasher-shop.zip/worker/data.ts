import type { Env, PageResult, Product, Shop, ShopQuery } from "./types";

const DEFAULT_LAT = 23.7465;
const DEFAULT_LNG = 90.3765;
const PAGE_SIZE = 10;
const DISTRICT_CENTERS: Record<string, { latitude: number; longitude: number }> = {
  ঢাকা: { latitude: DEFAULT_LAT, longitude: DEFAULT_LNG },
  চট্টগ্রাম: { latitude: 22.3569, longitude: 91.7832 },
  রাজশাহী: { latitude: 24.3636, longitude: 88.6241 },
};

export function distanceKm(lat1: number, lon1: number, lat2: number, lon2: number) {
  const radians = (value: number) => (value * Math.PI) / 180;
  const dLat = radians(lat2 - lat1);
  const dLon = radians(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(radians(lat1)) * Math.cos(radians(lat2)) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function queryCacheKey(request: Request, query: ShopQuery) {
  const url = new URL(request.url);
  const key = new URL("/__district-cache/v3/shops", url.origin);
  key.searchParams.set("district", query.district);
  key.searchParams.set("category", query.category ?? "all");
  key.searchParams.set("q", query.query?.trim().toLowerCase() ?? "");
  key.searchParams.set("page", String(query.page));
  key.searchParams.set("radius", String(query.radiusKm));
  key.searchParams.set("lat", query.latitude.toFixed(2));
  key.searchParams.set("lng", query.longitude.toFixed(2));
  return new Request(key.toString(), { method: "GET" });
}

function bounds(query: ShopQuery) {
  const minLat = query.latitude - query.radiusKm / 110.574;
  const maxLat = query.latitude + query.radiusKm / 110.574;
  const lonScale = Math.max(Math.cos((query.latitude * Math.PI) / 180), 0.2) * 111.32;
  const lonDelta = query.radiusKm / lonScale;
  return { minLat, maxLat, minLng: query.longitude - lonDelta, maxLng: query.longitude + lonDelta };
}

function isDistrictCenter(query: ShopQuery) {
  const center = DISTRICT_CENTERS[query.district];
  return Boolean(center && center.latitude === query.latitude && center.longitude === query.longitude);
}

export async function listShops(env: Env, request: Request, query: ShopQuery): Promise<PageResult<Shop>> {
  const canCache = Boolean(query.district) && !query.query && isDistrictCenter(query);
  const cache = (caches as unknown as { default: Cache }).default;
  const cacheKey = queryCacheKey(request, query);
  if (canCache) {
    const cached = await cache.match(cacheKey);
    if (cached) return (await cached.json()) as PageResult<Shop>;
  }

  const { minLat, maxLat, minLng, maxLng } = bounds(query);
  const districtClause = query.district ? " AND district = ?" : "";
  const categoryClause = query.category ? " AND category LIKE ?" : "";
  const searchClause = query.query ? " AND (name LIKE ? OR area LIKE ? OR category LIKE ?)" : "";
  const sql = `SELECT * FROM shops
    WHERE status = 'active'${districtClause}
      AND latitude BETWEEN ? AND ? AND longitude BETWEEN ? AND ?${categoryClause}${searchClause}
    ORDER BY is_boosted DESC, rating DESC, rating_count DESC
    LIMIT 300`;
  const bindings: unknown[] = [];
  if (query.district) bindings.push(query.district);
  bindings.push(minLat, maxLat, minLng, maxLng);
  if (query.category) bindings.push(`%${query.category}%`);
  if (query.query) {
    const search = `%${query.query.replace(/[\\%_]/g, "")}%`;
    bindings.push(search, search, search);
  }

  const result = await env.DB.prepare(sql).bind(...bindings).all<Shop>();
  const nearby = (result.results ?? [])
    .map((shop) => ({
      ...shop,
      distance_km: distanceKm(query.latitude, query.longitude, shop.latitude, shop.longitude),
    }))
    .filter((shop) => shop.distance_km <= query.radiusKm)
    .sort((a, b) =>
      b.is_boosted - a.is_boosted ||
      b.rating - a.rating ||
      b.rating_count - a.rating_count ||
      a.distance_km! - b.distance_km!,
    );
  const total = nearby.length;
  const start = (query.page - 1) * PAGE_SIZE;
  const page: PageResult<Shop> = {
    items: nearby.slice(start, start + PAGE_SIZE),
    page: query.page,
    pageSize: PAGE_SIZE,
    total,
  };

  if (canCache) {
    const response = Response.json(page, {
      headers: { "Cache-Control": "public, max-age=0, s-maxage=60" },
    });
    await cache.put(cacheKey, response);
  }
  return page;
}

export async function listNearbyShopIds(env: Env, query: ShopQuery): Promise<string[]> {
  const { minLat, maxLat, minLng, maxLng } = bounds(query);
  const districtClause = query.district ? " AND district = ?" : "";
  const sql = `SELECT id, latitude, longitude FROM shops
    WHERE status = 'active'${districtClause}
      AND latitude BETWEEN ? AND ? AND longitude BETWEEN ? AND ?
    LIMIT 5000`;
  const bindings: unknown[] = [];
  if (query.district) bindings.push(query.district);
  bindings.push(minLat, maxLat, minLng, maxLng);
  const result = await env.DB.prepare(sql).bind(...bindings).all<Pick<Shop, "id" | "latitude" | "longitude">>();
  return (result.results ?? [])
    .filter((shop) => distanceKm(query.latitude, query.longitude, shop.latitude, shop.longitude) <= query.radiusKm)
    .map((shop) => shop.id);
}

export async function getShop(env: Env, slug: string): Promise<Shop | null> {
  const result = await env.DB.prepare("SELECT * FROM shops WHERE slug = ? AND status = 'active' LIMIT 1")
    .bind(slug)
    .first<Shop>();
  return result ?? null;
}

export async function listProducts(
  env: Env,
  options: { shopId?: string; shopIds?: string[]; query?: string; category?: string; page?: number; pageSize?: number } = {},
) {
  const page = Math.max(1, options.page ?? 1);
  const pageSize = Math.max(1, Math.min(10, options.pageSize ?? PAGE_SIZE));
  if (options.shopIds && options.shopIds.length === 0) return { items: [] as Product[], page, pageSize, total: 0 };
  const conditions = ["p.in_stock = 1", "s.status = 'active'"];
  const bindings: unknown[] = [];
  if (options.shopId) {
    conditions.push("p.shop_id = ?");
    bindings.push(options.shopId);
  }
  if (options.shopIds) {
    const shopIds = [...new Set(options.shopIds)].slice(0, 500);
    conditions.push(`p.shop_id IN (${shopIds.map(() => "?").join(",")})`);
    bindings.push(...shopIds);
  }
  if (options.category) {
    conditions.push("p.category LIKE ?");
    bindings.push(`%${options.category}%`);
  }
  if (options.query) {
    conditions.push("(p.title LIKE ? OR p.category LIKE ? OR p.description LIKE ? OR s.name LIKE ?)");
    const q = `%${options.query.replace(/[\\%_]/g, "")}%`;
    bindings.push(q, q, q, q);
  }
  const where = conditions.join(" AND ");
  const countRow = await env.DB.prepare(`SELECT COUNT(*) AS count FROM products p JOIN shops s ON s.id = p.shop_id WHERE ${where}`)
    .bind(...bindings)
    .first<{ count: number }>();
  const total = Number(countRow?.count ?? 0);
  const offset = (page - 1) * pageSize;
  const result = await env.DB.prepare(`SELECT p.*, s.name AS shop_name, s.slug AS shop_slug, s.area AS shop_area
    FROM products p JOIN shops s ON s.id = p.shop_id WHERE ${where}
    ORDER BY p.is_featured DESC, p.created_at DESC LIMIT ? OFFSET ?`)
    .bind(...bindings, pageSize, offset)
    .all<Product>();
  return { items: result.results ?? [], page, pageSize, total };
}

export async function getProduct(env: Env, id: string) {
  return env.DB.prepare("SELECT p.*, s.name AS shop_name, s.slug AS shop_slug, s.area AS shop_area FROM products p JOIN shops s ON s.id = p.shop_id WHERE p.id = ? AND p.in_stock = 1 AND s.status = 'active' LIMIT 1")
    .bind(id)
    .first<Product>();
}

export async function getProductsByIds(env: Env, ids: string[]) {
  const safeIds = [...new Set(ids)].slice(0, 30);
  if (!safeIds.length) return [] as Product[];
  const placeholders = safeIds.map(() => "?").join(",");
  const rows = await env.DB.prepare(`SELECT p.*, s.name AS shop_name, s.slug AS shop_slug, s.area AS shop_area FROM products p JOIN shops s ON s.id = p.shop_id WHERE p.id IN (${placeholders}) AND p.in_stock = 1 AND s.status = 'active'`)
    .bind(...safeIds)
    .all<Product>();
  return rows.results ?? [];
}

export function parseShopQuery(url: URL): ShopQuery {
  const rawLatitude = url.searchParams.get("lat");
  const rawLongitude = url.searchParams.get("lng");
  const latitude = rawLatitude ? Number(rawLatitude) : Number.NaN;
  const longitude = rawLongitude ? Number(rawLongitude) : Number.NaN;
  const hasPoint = Number.isFinite(latitude) && Number.isFinite(longitude) && latitude >= -90 && latitude <= 90 && longitude >= -180 && longitude <= 180;
  const rawDistrict = url.searchParams.get("district");
  const district = rawDistrict === null ? "ঢাকা" : rawDistrict.slice(0, 60);
  const effectiveDistrict = district || (hasPoint ? "" : "ঢাকা");
  const center = DISTRICT_CENTERS[effectiveDistrict] ?? DISTRICT_CENTERS["ঢাকা"];
  const shopPage = url.searchParams.get("shopPage") ?? url.searchParams.get("page");
  return {
    district: effectiveDistrict,
    category: url.searchParams.get("category") || undefined,
    page: Math.max(1, Math.min(100, Number(shopPage) || 1)),
    latitude: hasPoint ? latitude : center.latitude,
    longitude: hasPoint ? longitude : center.longitude,
    radiusKm: Math.max(1, Math.min(5, Number(url.searchParams.get("radius")) || 5)),
    query: url.searchParams.get("q")?.slice(0, 80) || undefined,
  };
}

export function bnNumber(value: number) {
  return new Intl.NumberFormat("bn-BD", { maximumFractionDigits: 1 }).format(value);
}

export function bdt(value: number) {
  return `৳${new Intl.NumberFormat("bn-BD", { maximumFractionDigits: 0 }).format(value)}`;
}
