/// <reference types="@cloudflare/workers-types" />

export interface Env {
  DB: D1Database;
  IMAGES: R2Bucket;
  ASSETS: Fetcher;
  PUBLIC_BASE_URL?: string;
  IMAGE_ORIGIN?: string;
}

export interface Shop {
  id: string;
  slug: string;
  name: string;
  category: string;
  district: string;
  area: string;
  address: string;
  latitude: number;
  longitude: number;
  phone: string;
  whatsapp: string;
  hours: string;
  description: string;
  banner_url: string | null;
  rating: number;
  rating_count: number;
  is_boosted: number;
  status: string;
  distance_km?: number;
}

export interface Product {
  id: string;
  shop_id: string;
  title: string;
  category: string;
  description: string;
  price_bdt: number;
  old_price_bdt: number | null;
  unit: string;
  image_key: string | null;
  emoji: string;
  in_stock: number;
  is_featured: number;
  shop_name?: string;
  shop_slug?: string;
  shop_area?: string;
}

export interface ShopQuery {
  district: string;
  category?: string;
  page: number;
  latitude: number;
  longitude: number;
  radiusKm: number;
  query?: string;
}

export interface PageResult<T> {
  items: T[];
  page: number;
  pageSize: number;
  total: number;
}
