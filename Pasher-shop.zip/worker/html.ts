import type { PageResult, Product, Shop } from "./types";
import { bdt, bnNumber } from "./data";

const HERO_IMAGE = "/manus-storage/async-images/T72t3EiJwgjtQCyPtYGdqs/image-1.webp";
const SHOP_BANNER = "/manus-storage/async-images/T72t3EiJwgjtQCyPtYGdqs/image-2.webp";

export function esc(value: unknown) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]!);
}

function logo() {
  return `<a class="brand" href="/" aria-label="Pasher Shop হোম"><span class="brand-mark" aria-hidden="true"><svg viewBox="0 0 48 48"><path d="M5 22 24 7l19 15v21H5z"/><path d="M18 43V28h12v15"/><circle cx="38" cy="12" r="6"/></svg></span><span><b>পাশের শপ</b><small>Pasher Shop</small></span></a>`;
}

function header(active = "", locationLabel = "ঢাকা") {
  return `<div class="announcement"><div class="container announce-inner"><span><i class="pulse-dot"></i> Preview ডেমো: দোকান, রেটিং ও দাম নমুনা</span><a href="/join-shop">দোকান যোগ করুন — একদম ফ্রি <span aria-hidden="true">↗</span></a></div></div>
  <header class="site-header"><div class="container header-inner">${logo()}
    <form class="top-search" action="/search" method="get" role="search"><span class="search-icon" aria-hidden="true">⌕</span><label class="sr-only" for="top-q">দোকান বা পণ্য খুঁজুন</label><input id="top-q" type="search" name="q" placeholder="দোকান বা পণ্য খুঁজুন…"/><button type="submit">খুঁজুন</button></form>
    <div class="header-actions"><a class="location-pill" href="/search"><span aria-hidden="true">⌖</span><span><small>আপনার এলাকা</small><b>${esc(locationLabel)}</b></span><span aria-hidden="true">⌄</span></a><a class="account-link" href="/account"><span class="account-icon" aria-hidden="true">♙</span><span>অ্যাকাউন্ট</span></a></div>
  </div><nav class="container main-nav" aria-label="প্রধান নেভিগেশন"><a class="${active === "home" ? "active" : ""}" href="/">হোম</a><a href="/search?category=মুদি">মুদি ও বাজার</a><a href="/search?category=ফল">ফল ও সবজি</a><a href="/search?category=বই">বই ও স্টেশনারি</a><a href="/search?category=পোশাক">পোশাক</a><a class="nav-promo" href="/merchant">দোকানদারের জন্য <span aria-hidden="true">↗</span></a><a class="nav-cart" href="/cart">ব্যাগ <span aria-hidden="true">＋</span></a></nav></header>`;
}

function footer() {
  return `<footer class="site-footer"><div class="container footer-main"><div class="footer-brand">${logo()}<p>আপনার পাড়ার বিশ্বস্ত দোকান, এক ঠিকানায়।</p></div><div><b>Pasher Shop</b><a href="/search">দোকান খুঁজুন</a><a href="/join-shop">বিনামূল্যে দোকান যোগ করুন</a><a href="/merchant">দোকানদারদের সুবিধা</a></div><div><b>সহায়তা</b><a href="/account">কাস্টমার অ্যাকাউন্ট</a><a href="/cart">অর্ডার ও পেমেন্ট</a><a href="mailto:hello@pasher.shop">যোগাযোগ</a></div><div class="footer-note"><span class="footer-pin">⌖</span><p>আপনার এলাকার ছোট ব্যবসাকে সমর্থন করুন। কাছের দোকান থেকে কিনুন, পাড়ার সঙ্গে থাকুন।</p></div></div><div class="container footer-bottom"><span>© ২০২৬ Pasher Shop</span><span>আপনার পাড়া, আপনার দোকান</span></div></footer>`;
}

export function layout(title: string, body: string, active = "", description = "আপনার ৫ কিমির ভেতরের দোকান, পণ্য ও দাম—এক জায়গায়।", status = 200, locationLabel = "ঢাকা") {
  const html = `<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#16845b"><meta name="description" content="${esc(description)}"><title>${esc(title)} · Pasher Shop</title><link rel="icon" href="/favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="/styles.css"><script type="module" src="/enhance.js"></script></head><body>${header(active, locationLabel)}<main id="main-content">${body}</main>${footer()}</body></html>`;
  return new Response(html, { status, headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "public, max-age=0, s-maxage=60" } });
}

function searchForm(query = "", district = "ঢাকা", category = "") {
  return `<form class="search-panel" action="/search" method="get"><label class="search-field"><span aria-hidden="true">⌕</span><span class="sr-only">কী খুঁজছেন?</span><input type="search" name="q" value="${esc(query)}" placeholder="চাল, দুধ, ফল বা দোকানের নাম…"></label><label class="district-field"><span aria-hidden="true">⌖</span><span class="sr-only">জেলা</span><select name="district"><option ${district === "ঢাকা" ? "selected" : ""} value="ঢাকা">ঢাকা</option><option ${district === "চট্টগ্রাম" ? "selected" : ""} value="চট্টগ্রাম">চট্টগ্রাম</option><option ${district === "রাজশাহী" ? "selected" : ""} value="রাজশাহী">রাজশাহী</option><option ${district === "" ? "selected" : ""} value="">GPS (না হলে ঢাকা)</option></select></label><input type="hidden" name="category" value="${esc(category)}"><button class="button button-primary" type="submit">দোকান খুঁজুন <span aria-hidden="true">→</span></button><button type="button" class="location-use" data-use-location data-auto-submit aria-label="আমার অবস্থান দিয়ে কাছের দোকান খুঁজুন">⌖</button><input type="hidden" name="lat"><input type="hidden" name="lng"><span class="sr-only" data-location-status role="status"></span></form>`;
}

const categoryItems = [
  ["মুদি", "🥬", "মুদি ও বাজার"],
  ["ফল", "🍊", "ফল ও সবজি"],
  ["পোশাক", "🧵", "পোশাক"],
  ["বই", "📚", "বই ও স্টেশনারি"],
  ["ফার্মেসি", "✚", "ফার্মেসি"],
  ["বেকারি", "🥐", "বেকারি"],
] as const;

function shopCard(shop: Shop) {
  const distance = shop.distance_km === undefined ? "" : `<span class="distance-tag">⌖ ${bnNumber(shop.distance_km)} কিমি</span>`;
  const banner = shop.banner_url ? `<img src="${esc(shop.banner_url)}" alt="${esc(shop.name)} দোকানের ছবি" loading="lazy">` : `<span class="shop-avatar" aria-hidden="true">${esc(shop.name.slice(0, 1))}</span>`;
  return `<article class="shop-card ${shop.is_boosted ? "is-boosted" : ""}"><a class="shop-card-art" href="/@${encodeURIComponent(shop.slug)}">${banner}${shop.is_boosted ? '<span class="boost-label">স্পন্সরড</span>' : ""}<span class="open-label"><i></i> স্থানীয়</span></a><div class="shop-card-content"><div class="shop-card-title"><div><a href="/@${encodeURIComponent(shop.slug)}"><h3>${esc(shop.name)}</h3></a><p>${esc(shop.category)} <span>·</span> ${esc(shop.area)}</p></div><span class="rating">★ ${bnNumber(shop.rating)}</span></div><div class="shop-card-foot">${distance}<a href="/@${encodeURIComponent(shop.slug)}" class="text-link">দোকান দেখুন <span aria-hidden="true">→</span></a></div></div></article>`;
}

function productCard(product: Product, currentItems: string[] = [], referral = "") {
  const visual = product.image_key ? `<img src="/image/thumb/${encodeURIComponent(product.image_key)}" alt="${esc(product.title)}" loading="lazy">` : `<span>${esc(product.emoji)}</span>`;
  const sale = product.old_price_bdt && product.old_price_bdt > product.price_bdt
    ? `<span class="old-price">${bdt(product.old_price_bdt)}</span><span class="sale-badge">ছাড়</span>`
    : "";
  const ref = referral ? `&amp;ref=${encodeURIComponent(referral)}` : "";
  return `<article class="product-card"><a class="product-visual" href="/product/${encodeURIComponent(product.id)}" aria-label="${esc(product.title)} দেখুন">${visual}${product.old_price_bdt ? '<b class="product-offer">অফার</b>' : ""}</a><div class="product-info"><div class="product-meta"><span>${esc(product.category)}</span><span>· ${esc(product.unit)}</span></div><a href="/product/${encodeURIComponent(product.id)}"><h3>${esc(product.title)}</h3></a><a class="product-shop" href="/@${encodeURIComponent(product.shop_slug ?? "rahimstore")}">${esc(product.shop_name ?? "পাশের দোকান")} · ${esc(product.shop_area ?? "")}</a><div class="price-row"><strong>${bdt(product.price_bdt)}</strong>${sale}</div><form action="/cart" method="get" class="add-form"><input type="hidden" name="add" value="${esc(product.id)}"><input type="hidden" name="ref" value="${esc(referral)}"><button type="submit" class="button button-outline">ব্যাগে রাখুন <span aria-hidden="true">＋</span></button></form><noscript><a class="button button-outline fallback-buy" href="/checkout?item=${encodeURIComponent(product.id)}${ref}">সরাসরি অর্ডার</a></noscript></div></article>`;
}

function pagination(page: number, total: number, base: string, parameter = "page") {
  const pages = Math.max(1, Math.ceil(total / 10));
  if (pages <= 1) return "";
  const prev = page > 1 ? `<a class="page-link" href="${base}${base.includes("?") ? "&" : "?"}${parameter}=${page - 1}">← আগের ১০টি</a>` : `<span></span>`;
  const next = page < pages ? `<a class="page-link" href="${base}${base.includes("?") ? "&" : "?"}${parameter}=${page + 1}">পরের ১০টি →</a>` : `<span></span>`;
  return `<nav class="pagination" aria-label="পৃষ্ঠা নেভিগেশন">${prev}<span>পৃষ্ঠা ${bnNumber(page)} / ${bnNumber(pages)}</span>${next}</nav>`;
}

function sectionHeading(kicker: string, title: string, note = "") {
  return `<div class="section-heading"><div><span class="eyebrow">${kicker}</span><h2>${title}</h2>${note ? `<p>${note}</p>` : ""}</div></div>`;
}

export function homePage(shops: PageResult<Shop>, products: PageResult<Product>, district = "ঢাকা") {
  const shopItems = shops.items.map(shopCard).join("");
  const productItems = products.items.slice(0, 4).map((product) => productCard(product)).join("");
  const categories = categoryItems.map(([key, icon, label]) => `<a class="category-chip" href="/search?category=${encodeURIComponent(key)}"><span>${icon}</span><b>${label}</b><i aria-hidden="true">↗</i></a>`).join("");
  const shopsBlock = shopItems || `<div class="empty-state"><span>⌖</span><h3>এই এলাকায় এখনও দোকান খুঁজে পাওয়া যায়নি</h3><p>এলাকা বদলে আবার চেষ্টা করুন, অথবা দোকান যোগ করুন।</p><a class="button button-primary" href="/join-shop">দোকান যোগ করুন</a></div>`;
  return layout("আপনার পাশের দোকান", `<section class="hero container"><div class="hero-copy"><span class="hero-kicker"><i></i> পাড়ার বাজার, আরও কাছে</span><h1>আপনার ৫ কিমির<br><em>ভেতরেই</em> সব আছে।</h1><p>কাছের দোকান ঘুরে দেখুন, পণ্যের দাম জানুন, আর পছন্দের দোকান থেকে সরাসরি অর্ডার করুন।</p>${searchForm()}<div class="hero-proof"><span><b>০৳</b> দোকান যোগ দিতে</span><span><b>৫ কিমি</b> আপনার কাছাকাছি</span><span><b>১০০%</b> পাড়ার দোকান</span></div></div><div class="hero-art"><img src="${HERO_IMAGE}" alt="ঢাকার পাড়ার দোকানে ফল ও সবজি" fetchpriority="high"><div class="hero-note"><span class="hero-note-icon">⌖</span><span><b>আপনার পাশেই</b><small>বিশ্বস্ত স্থানীয় দোকান</small></span></div><div class="hero-offer"><span>আজকের পাড়া অফার</span><b>টাটকা বাজার, ভালো দামে</b></div></div></section>
  <section class="container category-section"><div class="category-head"><div><span class="eyebrow">এক নজরে</span><h2>কী খুঁজছেন আজ?</h2></div><a class="text-link" href="/search">সব ক্যাটাগরি <span aria-hidden="true">→</span></a></div><div class="category-list">${categories}</div></section>
  <section class="nearby-section"><div class="container"><div class="feed-layout"><div class="feed-main">${sectionHeading(`আপনার পাড়া · ${esc(district)}`, "জনপ্রিয় কাছের দোকান", "৫ কিমির মধ্যে খোলা ও পরিচিত দোকানগুলো")}</div><a class="text-link see-all" href="/search?district=${encodeURIComponent(district)}">সব দোকান দেখুন <span aria-hidden="true">→</span></a></div><div class="shop-grid">${shopsBlock}</div>${pagination(shops.page, shops.total, `/search?district=${encodeURIComponent(district)}`)}</div></section>
  <section class="container deals-section">${sectionHeading("আজকের খোঁজ", "দাম দেখে পছন্দ করুন", "আপনার এলাকার দোকান থেকে সরাসরি পাওয়া যায়") }<div class="product-grid">${productItems || '<p class="muted">এখনও কোনো পণ্য তালিকাভুক্ত হয়নি।</p>'}</div><div class="center-link"><a class="button button-outline" href="/search">আরও পণ্য খুঁজুন <span aria-hidden="true">→</span></a></div></section>
  <section class="container viral-panel"><div class="viral-mark" aria-hidden="true">↗</div><div><span class="eyebrow">Pasher Pass</span><h2>পাড়ার ভালো জিনিস,<br>পাশের মানুষকে জানান।</h2><p>পছন্দের দোকান শেয়ার করুন—আপনার বন্ধুরা স্থানীয় অফার পাবে, আর পাড়ার ব্যবসাও এগোবে।</p></div><a class="button button-light" href="/r/rahimstore">বন্ধুকে আমন্ত্রণ করুন <span aria-hidden="true">→</span></a><div class="viral-stamp" aria-hidden="true">পাশের<br>শপ</div></section>
  <section class="container seller-strip"><div class="seller-icon" aria-hidden="true">⌂</div><div><span class="eyebrow">দোকানদারদের জন্য</span><h2>আপনার দোকান, অনলাইনে—খরচ ছাড়াই।</h2><p>একটি লিংক, একটি QR, আর আপনার সব পণ্য-দাম এক জায়গায়।</p></div><a class="button button-primary" href="/join-shop">বিনামূল্যে দোকান যোগ করুন <span aria-hidden="true">→</span></a></section>`, "home", undefined, 200, district);
}

export function searchPage(shops: PageResult<Shop>, products: PageResult<Product>, url: URL) {
  const q = url.searchParams.get("q") ?? "";
  const rawDistrict = url.searchParams.get("district");
  const district = rawDistrict === null ? "ঢাকা" : rawDistrict;
  const category = url.searchParams.get("category") ?? "";
  const hasCoordinates = Boolean(url.searchParams.get("lat") && url.searchParams.get("lng"));
  const effectiveDistrict = hasCoordinates ? "" : district || "ঢাকা";
  const locationLabel = hasCoordinates ? "আপনার অবস্থান" : effectiveDistrict;
  const shopsHtml = shops.items.map(shopCard).join("");
  const productHtml = products.items.map((product) => productCard(product)).join("");
  const queryLabel = q ? `“${esc(q)}”` : category ? `“${esc(category)}”` : "আপনার এলাকার দোকান ও পণ্য";
  const baseParams = new URLSearchParams({ q, district: effectiveDistrict, category });
  if (hasCoordinates) {
    baseParams.set("lat", url.searchParams.get("lat") ?? "");
    baseParams.set("lng", url.searchParams.get("lng") ?? "");
  }
  const base = `/search?${baseParams.toString()}`;
  const distanceLabel = hasCoordinates
    ? "আপনার অবস্থান থেকে ৫ কিমির মধ্যে"
    : `${esc(locationLabel)} জেলার কেন্দ্র থেকে ৫ কিমির মধ্যে`;
  const filterCoordinates = hasCoordinates
    ? `<input type="hidden" name="lat" value="${esc(url.searchParams.get("lat") ?? "")}"><input type="hidden" name="lng" value="${esc(url.searchParams.get("lng") ?? "")}">`
    : "";
  const body = `<section class="container inner-hero"><div><span class="eyebrow">স্থানীয় খোঁজ</span><h1>${queryLabel} <em>খুঁজুন</em></h1><p>${distanceLabel}</p></div>${searchForm(q, effectiveDistrict, category)}</section><section class="container result-section"><div class="feed-layout">${sectionHeading("আপনার আশেপাশে", "দোকান", `${bnNumber(shops.total)}টি কাছের দোকান`)}<form method="get" action="/search" class="filter-inline"><input type="hidden" name="q" value="${esc(q)}"><input type="hidden" name="district" value="${esc(effectiveDistrict)}">${filterCoordinates}<label><span class="sr-only">ক্যাটাগরি</span><select name="category"><option value="">সব ক্যাটাগরি</option>${categoryItems.map(([key,,label]) => `<option value="${esc(key)}" ${category === key ? "selected" : ""}>${label}</option>`).join("")}</select></label><button class="button button-outline" type="submit">ফিল্টার</button></form></div><div class="shop-grid">${shopsHtml || '<p class="muted">এই শর্তে দোকান পাওয়া যায়নি।</p>'}</div>${pagination(shops.page, shops.total, base, "shopPage")}</section><section class="container result-section product-results">${sectionHeading("দাম দেখে নিন", "পণ্য", `${bnNumber(products.total)}টি পণ্য পাওয়া গেছে`)}<div class="product-grid">${productHtml || '<p class="muted">এই নামে পণ্য পাওয়া যায়নি।</p>'}</div>${pagination(products.page, products.total, base, "productPage")}</section>`;
  return layout("দোকান ও পণ্য খুঁজুন", body, "search", undefined, 200, locationLabel);
}
export function shopPage(shop: Shop, products: PageResult<Product>, referral = "") {
  const banner = shop.banner_url || SHOP_BANNER;
  const phone = shop.phone.replace(/[^+\d]/g, "");
  const whatsapp = shop.whatsapp.replace(/\D/g, "");
  const productsHtml = products.items.map((product) => productCard(product, [], referral)).join("");
  const minLng = shop.longitude - 0.006;
  const maxLng = shop.longitude + 0.006;
  const mapUrl = `https://www.openstreetmap.org/export/embed.html?bbox=${minLng}%2C${shop.latitude - 0.005}%2C${maxLng}%2C${shop.latitude + 0.005}&layer=mapnik&marker=${shop.latitude}%2C${shop.longitude}`;
  return layout(shop.name, `<section class="container shop-profile"><div class="shop-cover"><img src="${esc(banner)}" alt="${esc(shop.name)} দোকানের ব্যানার" fetchpriority="high"><span class="cover-shade"></span><div class="cover-label"><span class="store-avatar">${esc(shop.name.slice(0, 1))}</span><span class="rating rating-large">★ ${bnNumber(shop.rating)} <small>(${bnNumber(shop.rating_count)}টি মতামত)</small></span></div></div><div class="shop-profile-bar"><div><span class="eyebrow">${esc(shop.category)} <span>·</span> ${esc(shop.area)}, ${esc(shop.district)}</span><h1>${esc(shop.name)}</h1><p>${esc(shop.description)}</p><div class="shop-meta-line"><span>⌖ ${esc(shop.address)}</span><span>◷ ${esc(shop.hours)}</span><span>⌂ দোকান থেকে সংগ্রহ</span></div></div><div class="shop-cta"><a class="button button-primary" href="https://wa.me/${esc(whatsapp)}?text=${encodeURIComponent(`আসসালামু আলাইকুম, ${shop.name} থেকে একটি পণ্য জানতে চাই।`)}" rel="noopener">WhatsApp-এ কথা বলুন ↗</a><a class="button button-outline" href="tel:${esc(phone)}">ফোন করুন <span aria-hidden="true">☎</span></a><a class="button button-qr" href="/qr/@${encodeURIComponent(shop.slug)}.svg" download="${esc(shop.slug)}-qr.svg">QR ডাউনলোড <span aria-hidden="true">▦</span></a></div></div><div class="shop-link-strip"><span>দোকানের লিংক</span><code>pasher.shop/@${esc(shop.slug)}</code><a href="/r/${encodeURIComponent(shop.slug)}">বন্ধুকে শেয়ার করুন ↗</a></div></section><section class="container shop-content"><div class="shop-products"><div class="feed-layout">${sectionHeading("আজকের তালিকা", "পণ্য ও দাম", "দাম দোকানদারের দেওয়া; অর্ডারের আগে নিশ্চিত করুন") }<a class="text-link" href="/search?district=${encodeURIComponent(shop.district)}">আরও দোকান <span aria-hidden="true">→</span></a></div><div class="product-grid">${productsHtml || '<p class="muted">এই দোকানে এখনও পণ্য যোগ করা হয়নি।</p>'}</div>${pagination(products.page, products.total, `/@${encodeURIComponent(shop.slug)}`)}</div><aside class="shop-side"><div class="side-card map-card"><div class="side-card-head"><div><span class="eyebrow">আমাদের ঠিকানা</span><h2>দোকানে চলে আসুন</h2></div><span aria-hidden="true">⌖</span></div><iframe title="${esc(shop.name)}-এর মানচিত্র" src="${mapUrl}" loading="lazy" referrerpolicy="no-referrer" sandbox="allow-scripts allow-same-origin"></iframe><p>${esc(shop.address)}</p><a class="text-link" href="https://www.openstreetmap.org/?mlat=${shop.latitude}&mlon=${shop.longitude}#map=17/${shop.latitude}/${shop.longitude}" target="_blank" rel="noopener">দিকনির্দেশনা দেখুন ↗</a></div><div class="side-card pickup-card"><span class="pickup-icon">✓</span><div><b>দোকান থেকে সংগ্রহ করুন</b><p>অর্ডার করে সুবিধামতো দোকানে এসে পণ্য নিন।</p></div></div><div class="side-card share-card"><span class="eyebrow">Pasher Pass</span><h3>পাড়ার কাউকে বলুন</h3><p>এই দোকানটি শেয়ার করে স্থানীয় ব্যবসাকে এগিয়ে নিন।</p><a class="button button-outline" href="/r/${encodeURIComponent(shop.slug)}">শেয়ার লিংক খুলুন ↗</a></div></aside></section>`, "", `${shop.name} — ${shop.category}, ${shop.area}. Pasher Shop-এ পণ্য ও দাম দেখুন।`, 200, shop.district);
}

export function productPage(product: Product, shop: Shop | null) {
  if (!shop) return notFoundPage();
  const visual = product.image_key ? `<img src="/image/card/${encodeURIComponent(product.image_key)}" alt="${esc(product.title)}" loading="lazy">` : `<span>${esc(product.emoji)}</span>`;
  const sale = product.old_price_bdt ? `<span class="old-price">${bdt(product.old_price_bdt)}</span><span class="sale-badge">ছাড় চলছে</span>` : "";
  return layout(product.title, `<section class="container product-detail"><div class="product-detail-visual">${visual}${product.old_price_bdt ? '<b class="product-offer">অফার</b>' : ""}</div><div class="product-detail-copy"><nav class="breadcrumbs"><a href="/">হোম</a><span>/</span><a href="/@${encodeURIComponent(shop.slug)}">${esc(shop.name)}</a><span>/</span><span>${esc(product.title)}</span></nav><span class="eyebrow">${esc(product.category)} · ${esc(product.unit)}</span><h1>${esc(product.title)}</h1><p>${esc(product.description)}</p><div class="detail-price"><strong>${bdt(product.price_bdt)}</strong>${sale}</div><p class="muted">দাম দোকানদারের দেওয়া। অর্ডারের আগে দোকানের সঙ্গে নিশ্চিত করুন।</p><div class="detail-actions"><form action="/cart" method="get"><input type="hidden" name="add" value="${esc(product.id)}"><button class="button button-primary" type="submit">ব্যাগে রাখুন <span aria-hidden="true">＋</span></button></form><a class="button button-outline" href="/checkout?item=${encodeURIComponent(product.id)}">এখনই অর্ডার করুন →</a></div><div class="seller-mini"><span class="shop-avatar">${esc(shop.name.slice(0,1))}</span><span><small>পাওয়া যাবে</small><a href="/@${encodeURIComponent(shop.slug)}"><b>${esc(shop.name)}</b> · ${esc(shop.area)}</a></span><a class="text-link" href="/@${encodeURIComponent(shop.slug)}">দোকান দেখুন →</a></div><a class="text-link" href="https://wa.me/${esc(shop.whatsapp.replace(/\D/g, ""))}?text=${encodeURIComponent(`আসসালামু আলাইকুম, ${product.title} আছে কি?`)}" rel="noopener">দোকানকে WhatsApp করুন ↗</a></div></section>`, "", `${product.title} — ${bdt(product.price_bdt)}. ${shop.name} থেকে দেখুন।`);
}

export function cartPage(products: Product[], items: string[], referral = "") {
  const itemMap = new Map(products.map((product) => [product.id, product]));
  const itemCounts = new Map<string, number>();
  for (const id of items) itemCounts.set(id, Math.min(99, (itemCounts.get(id) ?? 0) + 1));
  const groups = new Map<string, { shopName: string; shopSlug: string; entries: Array<{ product: Product; quantity: number }> }>();
  for (const [id, quantity] of itemCounts) {
    const product = itemMap.get(id);
    if (!product) continue;
    const group = groups.get(product.shop_id) ?? {
      shopName: product.shop_name ?? "দোকান",
      shopSlug: product.shop_slug ?? "rahimstore",
      entries: [],
    };
    group.entries.push({ product, quantity });
    groups.set(product.shop_id, group);
  }
  const total = [...groups.values()].flatMap((group) => group.entries)
    .reduce((sum, entry) => sum + entry.product.price_bdt * entry.quantity, 0);
  const groupCards = [...groups.values()].map((group) => {
    const subtotal = group.entries.reduce((sum, entry) => sum + entry.product.price_bdt * entry.quantity, 0);
    const rows = group.entries.map(({ product, quantity }) =>
      `<li class="cart-row"><span class="cart-product-icon">${esc(product.emoji)}</span><div class="cart-row-copy"><a href="/product/${encodeURIComponent(product.id)}"><b>${esc(product.title)}</b></a><small>${esc(product.unit)} · ${quantity}টি</small></div><strong>${bdt(product.price_bdt * quantity)}</strong><a class="remove-link" href="/cart?remove=${encodeURIComponent(product.id)}">সরান</a></li>`,
    ).join("");
    const hidden = group.entries.flatMap(({ product, quantity }) =>
      Array.from({ length: quantity }, () => `<input type="hidden" name="item" value="${esc(product.id)}">`),
    ).join("");
    return `<article class="cart-shop-card"><div class="cart-shop-card-head"><span class="eyebrow">এই দোকানের অর্ডার</span><h2><a href="/@${encodeURIComponent(group.shopSlug)}">${esc(group.shopName)}</a></h2></div><ul class="cart-list">${rows}</ul><div class="cart-shop-total"><span>এই দোকানের subtotal</span><strong>${bdt(subtotal)}</strong></div><form action="/checkout" method="get">${hidden}<input type="hidden" name="ref" value="${esc(referral)}"><button class="button button-primary button-wide" type="submit">এই দোকানে অর্ডার করুন →</button></form></article>`;
  }).join("");
  const body = groupCards
    ? `<section class="container inner-hero"><div><span class="eyebrow">আপনার পছন্দ</span><h1>আপনার <em>ব্যাগ</em></h1><p>${bnNumber(items.length)}টি পণ্য · ${bnNumber(groups.size)}টি দোকান। প্রতিটি দোকানে আলাদা অর্ডার দিন।</p></div></section><section class="container cart-shop-groups">${groupCards}</section><section class="container cart-total-bar"><div><span class="eyebrow">সব দোকানের ব্যাগ</span><h2>মোট ${bdt(total)}</h2><p>একটি দোকানে অর্ডার করলে অন্য দোকানের পণ্য ব্যাগে থেকে যাবে।</p></div><a class="button button-outline" href="/search">আরও পণ্য যোগ করুন →</a></section>`
    : `<section class="container empty-cart"><span class="empty-bag">▱</span><span class="eyebrow">এখনও কিছু যোগ হয়নি</span><h1>আপনার ব্যাগ <em>খালি</em></h1><p>পাশের দোকান ঘুরে দেখুন, পছন্দের পণ্য ব্যাগে রাখুন।</p><a class="button button-primary" href="/search">দোকান ও পণ্য খুঁজুন →</a></section>`;
  return layout("আপনার ব্যাগ", body, "");
}

export function checkoutPage(products: Product[], referral = "") {
  if (!products.length) return layout("অর্ডার শুরু করুন", `<section class="container empty-cart"><span class="eyebrow">প্রথমে পণ্য বেছে নিন</span><h1>আপনার অর্ডার <em>শুরু করুন</em></h1><p>কাছের দোকানের পণ্য বেছে ব্যাগে রাখুন।</p><a class="button button-primary" href="/search">পণ্য খুঁজুন →</a></section>`);
  const total = products.reduce((sum, product) => sum + product.price_bdt, 0);
  const hidden = products.map((product) => `<input type="hidden" name="item" value="${esc(product.id)}">`).join("");
  const itemNames = products.map((product) => esc(product.title)).join(", ");
  return layout("অর্ডার নিশ্চিত করুন", `<section class="container inner-hero"><div><span class="eyebrow">একদম সহজে</span><h1>অর্ডার <em>নিশ্চিত করুন</em></h1><p>অ্যাকাউন্ট ছাড়াই অর্ডার করা যায়। দোকান আপনার সঙ্গে যোগাযোগ করবে।</p></div></section><section class="container checkout-layout"><form class="checkout-form" action="/api/orders" method="post"><h2>আপনার তথ্য</h2>${hidden}<input type="hidden" name="ref" value="${esc(referral)}"><input type="hidden" name="items_label" value="${itemNames}"><div class="form-grid"><label>আপনার নাম<input name="name" required maxlength="80" autocomplete="name" placeholder="যেমন: নুসরাত জাহান"></label><label>মোবাইল নম্বর<input name="phone" type="tel" required inputmode="tel" pattern="[+0-9 ()-]{8,20}" autocomplete="tel" placeholder="01XXXXXXXXX"></label></div><fieldset><legend>পণ্য কীভাবে নেবেন?</legend><label class="radio-row"><input type="radio" name="delivery" value="pickup" checked><span><b>দোকান থেকে নিয়ে যাব</b><small>ফোনে নিশ্চিত করে দোকানে আসুন</small></span></label><label class="radio-row"><input type="radio" name="delivery" value="delivery"><span><b>বাসায় ডেলিভারি চাই</b><small>ডেলিভারি খরচ দোকান জানাবে</small></span></label></fieldset><label class="full-label">ঠিকানা / এলাকার নাম<input name="address" maxlength="200" autocomplete="street-address" placeholder="ডেলিভারি চাইলে ঠিকানা লিখুন"></label><fieldset><legend>পেমেন্ট পদ্ধতি বেছে নিন</legend><div class="payment-grid"><label class="payment-option"><input type="radio" name="payment" value="bkash" checked><span class="pay-badge pay-bkash">b</span><b>বিকাশ</b></label><label class="payment-option"><input type="radio" name="payment" value="nagad"><span class="pay-badge pay-nagad">n</span><b>নগদ</b></label><label class="payment-option"><input type="radio" name="payment" value="rocket"><span class="pay-badge pay-rocket">r</span><b>রকেট</b></label><label class="payment-option"><input type="radio" name="payment" value="upay"><span class="pay-badge pay-upay">u</span><b>উপায়</b></label><label class="payment-option"><input type="radio" name="payment" value="bank"><span class="pay-badge pay-bank">৳</span><b>ব্যাংক</b></label><label class="payment-option"><input type="radio" name="payment" value="pickup"><span class="pay-badge pay-pickup">⌂</span><b>দোকানে</b></label></div><p class="payment-note">পেমেন্ট গেটওয়ে এখনো সংযুক্ত নয়। এই প্রিভিউতে টাকা কাটা হবে না; দোকানদার অর্ডার নিশ্চিত করে পেমেন্টের নির্দেশনা দেবেন।</p></fieldset><label class="full-label">দোকানকে কিছু জানাতে চান? <textarea name="note" rows="3" maxlength="300" placeholder="যেমন: বিকেল ৫টার পর ফোন করুন"></textarea></label><button class="button button-primary button-wide" type="submit">${bdt(total)} — অর্ডার পাঠান <span aria-hidden="true">→</span></button><p class="fineprint">অর্ডার পাঠালে দোকান আপনার নম্বরে যোগাযোগ করবে। আপনি চাইলে পরে দোকানে গিয়ে পণ্য নিতে পারবেন।</p></form><aside class="order-summary"><span class="eyebrow">আপনার অর্ডার</span><h2>পণ্যের বিবরণ</h2><ul class="summary-products">${products.map((product) => `<li><span>${esc(product.emoji)} ${esc(product.title)}</span><b>${bdt(product.price_bdt)}</b></li>`).join("")}</ul><div class="summary-total"><span>আনুমানিক মোট</span><strong>${bdt(total)}</strong></div><p class="fineprint">দাম ও ডেলিভারি দোকান নিশ্চিত করবে।</p></aside></section>`);
}

export function confirmationPage(order: { id: string; total_bdt: number; payment_method: string; delivery_option: string } | null, hasOtherItems = false) {
  if (!order) return notFoundPage();
  const paymentLabels: Record<string, string> = { bkash: "বিকাশ", nagad: "নগদ", rocket: "রকেট", upay: "উপায়", bank: "ব্যাংক ট্রান্সফার", pickup: "দোকানে গিয়ে" };
  const nextStep = hasOtherItems
    ? `<p>আপনার ব্যাগে অন্য দোকানের পণ্য আছে। চাইলে সেগুলোর জন্য আলাদা অর্ডার পাঠাতে পারেন।</p><a class="button button-primary" href="/cart">অন্য দোকানের অর্ডার দিন →</a>`
    : `<a class="button button-primary" href="/">হোমে ফিরে যান →</a>`;
  return layout("অর্ডার গ্রহণ করা হয়েছে", `<section class="container success-page"><div class="success-check">✓</div><span class="eyebrow">ধন্যবাদ</span><h1>আপনার অর্ডার <em>পৌঁছে গেছে।</em></h1><p>দোকান আপনার নম্বরে যোগাযোগ করবে। পেমেন্টের কোনো টাকা এই প্রিভিউতে কাটা হয়নি।</p><div class="success-receipt"><div><span>অর্ডার রেফারেন্স</span><b>${esc(order.id.slice(0, 8).toUpperCase())}</b></div><div><span>আনুমানিক মোট</span><b>${bdt(order.total_bdt)}</b></div><div><span>পণ্য নেওয়ার উপায়</span><b>${order.delivery_option === "pickup" ? "দোকান থেকে সংগ্রহ" : "ডেলিভারি"}</b></div><div><span>পেমেন্ট পদ্ধতি</span><b>${paymentLabels[order.payment_method] ?? "দোকানের সঙ্গে নিশ্চিত করুন"}</b></div></div>${nextStep}</section>`);
}

export function joinShopPage() {
  return layout("বিনামূল্যে দোকান যোগ করুন", `<section class="container inner-hero seller-hero"><div><span class="eyebrow">শুরু করতে খরচ নেই</span><h1>আপনার দোকান <em>অনলাইনে আনুন।</em></h1><p>দোকানের পেজ, পণ্যের তালিকা, দাম, লোকেশন ও একটি shareable QR—সব এক জায়গায়।</p></div><div class="seller-zero">৳<b>০</b><small>দোকান যোগ করতে</small></div></section><section class="container join-layout"><form class="checkout-form" action="/api/shops" method="post"><h2>দোকানের তথ্য দিন</h2><div class="form-grid"><label>দোকানের নাম<input name="name" required maxlength="100" placeholder="যেমন: রহিম স্টোর"></label><label>পেজের নাম / URL<input name="slug" pattern="[a-zA-Z0-9-]{3,40}" maxlength="40" placeholder="rahimstore"><small>যেমন pasher.shop/@rahimstore</small></label><label>দোকানের ধরন<select name="category" required>${categoryItems.map(([key,,label])=>`<option value="${esc(key)}">${label}</option>`).join("")}</select></label><label>মোবাইল নম্বর<input name="phone" required inputmode="tel" pattern="[+0-9 ()-]{8,20}" placeholder="01XXXXXXXXX"></label><label>WhatsApp নম্বর<input name="whatsapp" inputmode="tel" pattern="[+0-9 ()-]{8,20}" placeholder="01XXXXXXXXX"></label><label>জেলা<input name="district" required value="ঢাকা" maxlength="60"></label><label>এলাকা<input name="area" required maxlength="80" placeholder="যেমন: ধানমন্ডি"></label></div><fieldset class="location-fieldset"><legend>দোকানের সঠিক অবস্থান</legend><p>দোকানে দাঁড়িয়ে অবস্থান বোতাম চাপুন, অথবা মানচিত্র থেকে অক্ষাংশ ও দ্রাঘিমাংশ লিখুন।</p><div class="form-grid"><label>অক্ষাংশ<input name="latitude" type="number" min="-90" max="90" step="0.000001" inputmode="decimal" required placeholder="23.7465"></label><label>দ্রাঘিমাংশ<input name="longitude" type="number" min="-180" max="180" step="0.000001" inputmode="decimal" required placeholder="90.3765"></label></div><button class="button button-outline location-use-wide" type="button" data-use-location>এই জায়গার অবস্থান নিন ⌖</button><span class="location-status" data-location-status role="status" aria-live="polite"></span></fieldset><label class="full-label">দোকানের ঠিকানা<input name="address" required maxlength="200" placeholder="রোড, এলাকা, জেলা"></label><label class="full-label">দোকান সম্পর্কে <textarea name="description" rows="3" maxlength="240" placeholder="কী পাওয়া যায়, কখন খোলা থাকে"></textarea></label><button class="button button-primary button-wide" type="submit">বিনামূল্যে দোকান যোগ করুন →</button><p class="fineprint">দোকান পেজ বিনামূল্যে। Boost ও বিজ্ঞাপন ঐচ্ছিক পেইড সুবিধা; এই প্রিভিউতে কোনো চার্জ হবে না।</p></form><aside class="seller-benefits"><span class="eyebrow">আপনি পাবেন</span><h2>দোকানের জন্য<br>ডিজিটাল ঠিকানা।</h2><div class="benefit-row"><i>⌂</i><span><b>নিজস্ব দোকান পেজ</b><small><code>pasher.shop/@আপনারনাম</code> লিংক</small></span></div><div class="benefit-row"><i>▦</i><span><b>প্রিন্ট-যোগ্য QR</b><small>দোকানের সামনে বা প্যাকেটে দিন</small></span></div><div class="benefit-row"><i>৳</i><span><b>সঠিক দাম, সহজ অর্ডার</b><small>গ্রাহক আপনার সঙ্গে সরাসরি কথা বলে</small></span></div></aside></section>`);
}

export function merchantPage() {
  return layout("দোকানদারের জন্য", `<section class="container inner-hero merchant-hero"><div><span class="eyebrow">স্বাধীন দোকানের ডিজিটাল সহকারী</span><h1>পাশের মানুষের কাছে<br><em>আরও পরিচিত হন।</em></h1><p>দোকান যোগ দেওয়া বিনামূল্যে। চাইলে প্রচার, বিক্রির তথ্য আর নতুন ক্রেতা আনার বাড়তি সুবিধা নিন।</p><a class="button button-primary" href="/join-shop">ফ্রি দোকান পেজ খুলুন →</a></div><div class="merchant-illustration"><span class="merchant-shop">⌂</span><span class="merchant-spark">✦</span><span class="merchant-stats"><b>ডেমো</b><small>নমুনা dashboard</small></span></div></section><section class="container plans-section">${sectionHeading("ঐচ্ছিক পেইড সুবিধা", "দোকান বড় হলে, প্রচারও বড় করুন", "দোকান যোগ দিতে কোনো খরচ নেই · Preview-তে payment চালু নয়") }<div class="plan-grid"><article class="plan-card"><span class="eyebrow">দ্রুত নজরে</span><h3>দোকান Boost</h3><p>আপনার দোকানকে এলাকার তালিকায় সবার আগে দেখান।</p><div class="plan-price">৳১৯৯ <small>/ ৭ দিন · ডেমো মূল্য</small></div><ul><li>নিকটবর্তী ফিডে বুস্টেড ব্যাজ</li><li>জেলা/এলাকা অনুযায়ী প্রচার</li><li>Pasher Pass QR</li></ul><form action="/api/promotions" method="post"><label class="promotion-shop-input">দোকানের handle<input name="shop" required pattern="[a-z0-9-]{3,40}" maxlength="40" placeholder="rahimstore"></label><input type="hidden" name="type" value="boost"><input type="hidden" name="package" value="boost-7"><button class="button button-outline button-wide" type="submit">প্যাকেজ দেখুন</button></form></article><article class="plan-card plan-featured"><span class="plan-ribbon">জনপ্রিয়</span><span class="eyebrow">অফারে নতুন ক্রেতা</span><h3>পণ্য বিজ্ঞাপন</h3><p>ছাড়ের পণ্যকে আপনার এলাকার মানুষের সামনে তুলে ধরুন।</p><div class="plan-price">৳২৯৯ <small>/ ৭ দিন · ডেমো মূল্য</small></div><ul><li>অফার ট্যাগসহ পণ্য প্রচার</li><li>ক্যাটাগরি ও এলাকার target</li><li>দর্শক ও click summary</li></ul><form action="/api/promotions" method="post"><label class="promotion-shop-input">দোকানের handle<input name="shop" required pattern="[a-z0-9-]{3,40}" maxlength="40" placeholder="rahimstore"></label><input type="hidden" name="type" value="discount_ad"><input type="hidden" name="package" value="ad-7"><button class="button button-primary button-wide" type="submit">প্যাকেজ দেখুন →</button></form></article><article class="plan-card"><span class="eyebrow">ব্যবসার হিসাব</span><h3>Shop Pro</h3><p>দোকানের অগ্রগতি বুঝুন, পণ্যের তালিকা আরও সুন্দর করুন।</p><div class="plan-price">৳৪৯৯ <small>/ মাস · ডেমো মূল্য</small></div><ul><li>বিক্রি ও দর্শকের analytics</li><li>Verified shop profile</li><li>বেশি পণ্য ও offer tools</li></ul><form action="/api/promotions" method="post"><label class="promotion-shop-input">দোকানের handle<input name="shop" required pattern="[a-z0-9-]{3,40}" maxlength="40" placeholder="rahimstore"></label><input type="hidden" name="type" value="analytics"><input type="hidden" name="package" value="pro-month"><button class="button button-outline button-wide" type="submit">Pro সুবিধা দেখুন</button></form></article></div><p class="plans-note">দাম ও প্যাকেজ উদাহরণমাত্র। Merchant sign-in/ownership যাচাই ও payment onboarding এখনো সংযুক্ত নয়; Preview-তে কোনো টাকা নেওয়া হবে না এবং কোনো promotion চালু হবে না।</p></section><section class="container viral-explainer"><div class="viral-mark">↗</div><div><span class="eyebrow">Pasher Pass · share করুন, পাড়া বাড়ুক</span><h2>ভালো দোকান খুঁজে পেলে,<br>পাশের মানুষকে জানান।</h2><p>আপনার QR বা share link দিয়ে নতুন ক্রেতা এলে দোকান referral coupon বা loyalty stamp দিতে পারবে। অফার দোকানদার নিয়ন্ত্রণ করবেন।</p></div><a class="button button-primary" href="/r/rahimstore">একটি উদাহরণ দেখুন →</a></section>`, "");
}

export function accountPage() {
  return layout("গ্রাহক অ্যাকাউন্ট", `<section class="container account-page"><div class="account-illustration">♙</div><span class="eyebrow">আপনার ইচ্ছা হলে</span><h1>অ্যাকাউন্ট ছাড়াই<br><em>অর্ডার করতে পারবেন।</em></h1><p>Guest checkout-এ শুধু নাম ও ফোন নম্বর দিলেই অর্ডার যাবে। অর্ডারের ইতিহাস, পছন্দের দোকান ও Pasher Pass reward একটি অ্যাকাউন্টে রাখতে customer sign-in provider সংযুক্ত করতে হবে।</p><a class="button button-primary" href="/search">দোকান দেখুন →</a><p class="fineprint">ঐচ্ছিক account sign-in এই preview-তে সক্রিয় নয়; customer account provider যোগ হলে এখানে চালু হবে।</p></section>`);
}

export function referralPage(shop: Shop | null) {
  if (!shop) return notFoundPage();
  return layout("Pasher Pass — স্থানীয় দোকান শেয়ার করুন", `<section class="container referral-page"><div class="referral-stamp">P</div><span class="eyebrow">Pasher Pass · আপনার পাড়ার সুপারিশ</span><h1>কাছের ভালো দোকান,<br><em>পাশের মানুষের জন্য।</em></h1><p>আপনার পরিচিত কেউ ${esc(shop.name)}-এর পণ্য খুঁজছেন? এই লিংক পাঠিয়ে স্থানীয় দোকানকে সমর্থন দিন। ${esc(shop.name)}-এর অফার ও পণ্যের দাম সরাসরি দেখুন।</p><div class="referral-store"><span class="shop-avatar">${esc(shop.name.slice(0,1))}</span><span><b>${esc(shop.name)}</b><small>${esc(shop.category)} · ${esc(shop.area)}</small></span><span class="rating">★ ${bnNumber(shop.rating)}</span></div><a class="button button-primary" href="/@${encodeURIComponent(shop.slug)}?ref=${encodeURIComponent(shop.slug)}">দোকান ও পণ্য দেখুন →</a><p class="fineprint">দোকানভেদে referral coupon/loyalty offer থাকতে পারে; এই Preview-তে reward redemption চালু নয়।</p></section>`);
}

export function notFoundPage() {
  return layout("পেজটি পাওয়া যায়নি", `<section class="container empty-cart"><span class="empty-bag">⌕</span><span class="eyebrow">৪০৪ · ঠিকানাটি খুঁজে পেলাম না</span><h1>এই পেজ <em>নেই।</em></h1><p>দোকানের লিংকটি ঠিক আছে কি না দেখুন, অথবা কাছের দোকান খুঁজুন।</p><a class="button button-primary" href="/">হোমে ফিরুন →</a></section>`, "", "এই Pasher Shop পেজটি পাওয়া যায়নি।", 404);
}
