import qrcode from "qrcode-generator";
import { getProduct, getProductsByIds, getShop, listNearbyShopIds, listProducts, listShops, parseShopQuery } from "./data";
import {
  accountPage,
  cartPage,
  checkoutPage,
  confirmationPage,
  homePage,
  joinShopPage,
  layout,
  merchantPage,
  notFoundPage,
  productPage,
  referralPage,
  searchPage,
  shopPage,
} from "./html";
import type { Env, Product } from "./types";

const PAYMENT_METHODS = new Set(["bkash", "nagad", "rocket", "upay", "bank", "pickup"]);
const PROMOTION_TYPES = new Set(["boost", "discount_ad", "analytics", "verified"]);
const PROMOTION_PACKAGES = new Set(["boost-7", "ad-7", "pro-month"]);

function json(data: unknown, status = 200, headers: HeadersInit = {}) {
  return Response.json(data, { status, headers: { "Cache-Control": "no-store", ...headers } });
}

function redirect(location: string, status = 303, extraHeaders: HeadersInit = {}) {
  return new Response(null, { status, headers: { Location: location, "Cache-Control": "no-store", ...extraHeaders } });
}

function pageMessage(title: string, message: string, href = "/", label = "হোমে ফিরুন") {
  return layout(title, `<section class="container empty-cart"><span class="empty-bag">✓</span><span class="eyebrow">Pasher Shop</span><h1>${title}</h1><p>${message}</p><a class="button button-primary" href="${href}">${label} →</a></section>`);
}

function validSlug(value: string) {
  return /^[a-z0-9](?:[a-z0-9-]{1,38}[a-z0-9])?$/.test(value);
}

function cleanSlug(value: string) {
  return value.trim().toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40);
}

function text(form: FormData, name: string, limit = 240) {
  const value = form.get(name);
  return (typeof value === "string" ? value : "").trim().slice(0, limit);
}

function formItems(form: FormData) {
  return form.getAll("item").filter((value): value is string => typeof value === "string").slice(0, 30);
}

function redirectWithReferrerCheck(request: Request) {
  const origin = request.headers.get("Origin");
  const fetchSite = request.headers.get("Sec-Fetch-Site");
  if (fetchSite === "cross-site") return false;
  if (!origin) return fetchSite === "same-origin" || fetchSite === "none";
  try {
    return new URL(origin).host === new URL(request.url).host;
  } catch {
    return false;
  }
}

function isAssetPath(path: string) {
  return path === "/favicon.svg" || path === "/styles.css" || path === "/enhance.js" || path === "/manus-routes.json" || path.startsWith("/assets/") || path.startsWith("/src/");
}

function allItemIds(url: URL) {
  const raw = url.searchParams.get("items");
  const commaSeparated = raw ? raw.split(",").filter(Boolean) : [];
  return [...url.searchParams.getAll("item"), ...commaSeparated].slice(0, 30);
}

function readCartCookie(request: Request) {
  const cookie = request.headers.get("Cookie") ?? "";
  const pair = cookie.split(";").map((part) => part.trim()).find((part) => part.startsWith("ps_cart="));
  if (!pair) return [] as string[];
  try {
    return decodeURIComponent(pair.slice("ps_cart=".length)).split(",").filter((id) => /^[a-z0-9-]{1,80}$/.test(id)).slice(0, 30);
  } catch {
    return [] as string[];
  }
}

function cartCookie(request: Request, items: string[]) {
  const isHttps = new URL(request.url).protocol === "https:";
  const security = isHttps ? "; Secure; SameSite=None" : "; SameSite=Lax";
  const maxAge = items.length ? 60 * 60 * 24 * 30 : 0;
  return `ps_cart=${encodeURIComponent(items.join(","))}; Path=/; Max-Age=${maxAge}; HttpOnly${security}`;
}

function attachCartCookie(request: Request, response: Response, items: string[]) {
  const headers = new Headers(response.headers);
  headers.append("Set-Cookie", cartCookie(request, items));
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}

function privateResponse(response: Response) {
  const headers = new Headers(response.headers);
  headers.set("Cache-Control", "private, no-store");
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}

async function handleShopJoin(request: Request, env: Env) {
  if (!redirectWithReferrerCheck(request)) return pageMessage("ফর্মটি গ্রহণ করা যায়নি", "আবার চেষ্টা করুন।", "/join-shop", "ফর্মে ফিরুন");
  const form = await request.formData();
  const name = text(form, "name", 100);
  const category = text(form, "category", 60);
  const phone = text(form, "phone", 24);
  const whatsapp = text(form, "whatsapp", 24) || phone;
  const district = text(form, "district", 60) || "ঢাকা";
  const area = text(form, "area", 80);
  const address = text(form, "address", 200);
  const latitudeText = text(form, "latitude", 24);
  const longitudeText = text(form, "longitude", 24);
  const latitude = Number(latitudeText);
  const longitude = Number(longitudeText);
  const description = text(form, "description", 240);
  const phoneDigits = phone.replace(/\D/g, "");
  if (name.length < 2 || !category || phoneDigits.length < 8 || !area || !address || !latitudeText || !longitudeText || !Number.isFinite(latitude) || !Number.isFinite(longitude) || latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
    return pageMessage("আরেকবার দেখে নিন", "দোকানের নাম, ধরন, ফোন, এলাকা, ঠিকানা এবং বৈধ অক্ষাংশ-দ্রাঘিমাংশ পূরণ করুন।", "/join-shop", "ফর্মে ফিরুন");
  }

  const id = `shop-${crypto.randomUUID()}`;
  const generated = cleanSlug(name);
  const requestedSlug = cleanSlug(text(form, "slug", 40));
  const candidate = requestedSlug || generated;
  const slug = validSlug(candidate) ? candidate : `pasher-${crypto.randomUUID().slice(0, 8)}`;
  try {
    await env.DB.prepare(`INSERT INTO shops (id, slug, name, category, district, area, address, latitude, longitude, phone, whatsapp, description, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')`)
      .bind(id, slug, name, category, district, area, address, latitude, longitude, phone, whatsapp, description)
      .run();
  } catch (error) {
    console.warn("Shop onboarding write failed.", error);
    return pageMessage("দোকানের তথ্য জমা হয়নি", "দয়া করে পরে আবার চেষ্টা করুন।", "/join-shop", "ফর্মে ফিরুন");
  }
  return pageMessage("দোকানের অনুরোধ জমা হয়েছে", `ধন্যবাদ, ${name}। দোকানের পেজটি এখন পর্যালোচনার জন্য রাখা হয়েছে। যাচাই ও মালিকের sign-in সেটআপ ছাড়া এটি public করা হবে না।`, "/merchant", "দোকানদার সুবিধা দেখুন");
}

async function handlePromotion(request: Request, env: Env) {
  if (!redirectWithReferrerCheck(request)) return pageMessage("অনুরোধটি গ্রহণ করা যায়নি", "আবার চেষ্টা করুন।", "/merchant", "ফিরে যান");
  const form = await request.formData();
  const shop = text(form, "shop", 40);
  const type = text(form, "type", 40);
  const packageCode = text(form, "package", 40);
  if (!validSlug(shop) || !PROMOTION_TYPES.has(type) || !PROMOTION_PACKAGES.has(packageCode)) return pageMessage("এই প্যাকেজটি পাওয়া যায়নি", "দোকানদার সুবিধা থেকে আবার বেছে নিন।", "/merchant", "প্যাকেজ দেখুন");
  try {
    const existing = await getShop(env, shop);
    if (!existing) return pageMessage("দোকানটি পাওয়া যায়নি", "দোকানের পেজ থেকে আবার প্যাকেজ বেছে নিন।", "/merchant", "প্যাকেজ দেখুন");
    await env.DB.prepare("INSERT INTO promotion_requests (id, shop_slug, promotion_type, package_code, status) VALUES (?, ?, ?, ?, 'demo_pending')")
      .bind(crypto.randomUUID(), shop, type, packageCode)
      .run();
  } catch (error) {
    console.warn("Promotion request failed.", error);
    return pageMessage("অনুরোধটি জমা হয়নি", "পরে আবার চেষ্টা করুন।", "/merchant", "ফিরে যান");
  }
  return pageMessage("প্যাকেজটি সংরক্ষিত হয়েছে", "এটি শুধু Preview অনুরোধ। Boost বা বিজ্ঞাপনের টাকা নেওয়া হয়নি; merchant account ও payment gateway যুক্ত হলে বাস্তব প্রচার চালু হবে।", "/merchant", "আরও সুবিধা দেখুন");
}

async function handleOrder(request: Request, env: Env) {
  if (!redirectWithReferrerCheck(request)) return pageMessage("অর্ডারটি গ্রহণ করা যায়নি", "পেজটি refresh করে আবার চেষ্টা করুন।", "/cart", "ব্যাগে ফিরুন");
  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return pageMessage("ফর্মটি পড়া যায়নি", "আপনার অর্ডার আবার পাঠান।", "/cart", "ব্যাগে ফিরুন");
  }
  const name = text(form, "name", 80);
  const phone = text(form, "phone", 24);
  const digits = phone.replace(/\D/g, "");
  const delivery = text(form, "delivery", 20);
  const address = text(form, "address", 200);
  const payment = text(form, "payment", 20);
  const note = text(form, "note", 300);
  const ids = formItems(form);
  if (name.length < 2 || digits.length < 8 || !["pickup", "delivery"].includes(delivery) || !PAYMENT_METHODS.has(payment) || !ids.length) {
    return pageMessage("তথ্যগুলো ঠিক করে দিন", "নাম, সঠিক ফোন নম্বর, পণ্য এবং পণ্য নেওয়ার উপায় নির্বাচন করুন।", "/cart", "ব্যাগে ফিরুন");
  }
  if (delivery === "delivery" && address.length < 5) return pageMessage("ডেলিভারি ঠিকানা দরকার", "বাসায় ডেলিভারি চাইলে আপনার এলাকা ও ঠিকানা লিখুন।", "/checkout", "অর্ডার ফর্মে ফিরুন");

  const counts = new Map<string, number>();
  for (const id of ids) counts.set(id, Math.min(99, (counts.get(id) ?? 0) + 1));
  let products: Product[];
  try {
    products = await getProductsByIds(env, [...counts.keys()]);
  } catch (error) {
    console.warn("D1 product lookup for order failed.", error);
    return pageMessage("অর্ডার নেওয়া যাচ্ছে না", "দোকানের পণ্যের তালিকা এই মুহূর্তে পাওয়া যাচ্ছে না।", "/cart", "পরে আবার চেষ্টা করুন");
  }
  if (products.length !== counts.size) return pageMessage("একটি পণ্য আর পাওয়া যাচ্ছে না", "ব্যাগে ফিরে পণ্যটি আবার বেছে নিন।", "/cart", "ব্যাগে ফিরুন");
  const shopIds = [...new Set(products.map((product) => product.shop_id))];
  if (shopIds.length !== 1) return pageMessage("দোকানভিত্তিক অর্ডার দিন", "একাধিক দোকানের পণ্য আলাদা অর্ডার হিসেবে পাঠাতে হবে। ব্যাগে ফিরে প্রতিটি দোকানের জন্য আলাদা অর্ডার দিন।", "/cart", "দোকানভিত্তিক ব্যাগ দেখুন");
  const shopId = shopIds[0];
  const total = products.reduce((sum, product) => sum + product.price_bdt * (counts.get(product.id) ?? 1), 0);
  const orderId = crypto.randomUUID();
  const publicToken = crypto.randomUUID().replaceAll("-", "");
  const referral = text(form, "ref", 40);
  const referralSlug = validSlug(referral) ? referral : null;
  const statements = [
    env.DB.prepare(`INSERT INTO orders (id, public_token, shop_id, customer_name, customer_phone, delivery_option, delivery_address, payment_method, payment_status, referral_slug, total_bdt, note)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'awaiting_merchant_setup', ?, ?, ?)`)
      .bind(orderId, publicToken, shopId, name, phone, delivery, address, payment, referralSlug, total, note),
    ...products.map((product) => env.DB.prepare(`INSERT INTO order_items (order_id, product_id, product_title, quantity, unit_price_bdt) VALUES (?, ?, ?, ?, ?)`)
      .bind(orderId, product.id, product.title, counts.get(product.id) ?? 1, product.price_bdt)),
  ];
  if (referralSlug) {
    statements.push(env.DB.prepare("INSERT INTO referral_events (id, shop_slug, order_id, event_type) VALUES (?, ?, ?, 'order')")
      .bind(crypto.randomUUID(), referralSlug, orderId));
  }
  try {
    await env.DB.batch(statements);
  } catch (error) {
    console.warn("D1 order transaction failed.", error);
    return pageMessage("অর্ডারটি জমা হয়নি", "দয়া করে একটু পরে আবার চেষ্টা করুন।", "/cart", "ব্যাগে ফিরুন");
  }
  const remainingCounts = new Map(counts);
  const remainingItems = readCartCookie(request).filter((id) => {
    const count = remainingCounts.get(id) ?? 0;
    if (count <= 0) return true;
    remainingCounts.set(id, count - 1);
    return false;
  });
  return redirect(`/order-confirmation?ref=${publicToken}&more=${remainingItems.length ? "1" : "0"}`, 303, { "Set-Cookie": cartCookie(request, remainingItems) });
}

async function serveMedia(request: Request, env: Env, path: string) {
  const isImageRequest = path.startsWith("/image/");
  const remainder = path.slice(isImageRequest ? "/image/".length : "/media/".length);
  const parts = remainder.split("/").filter(Boolean);
  const preset = isImageRequest ? (parts.shift() ?? "original") : "original";
  const encodedKey = parts.join("/");
  let key = "";
  try { key = decodeURIComponent(encodedKey); } catch { return new Response("Not found", { status: 404 }); }
  if (!key || key.length > 500 || key.includes("..") || !/^[A-Za-z0-9/_ .-]+$/.test(key)) return new Response("Not found", { status: 404 });

  const sizes: Record<string, { width: number; height?: number }> = {
    thumb: { width: 320, height: 240 },
    card: { width: 640, height: 480 },
    banner: { width: 1440, height: 560 },
  };
  const transform = sizes[preset ?? ""];
  if (transform && env.IMAGE_ORIGIN) {
    const origin = new URL(env.IMAGE_ORIGIN);
    const original = new URL(`/originals/${encodeURIComponent(key).replace(/%2F/g, "/")}`, origin);
    try {
      const transformed = await fetch(original.toString(), {
        cf: { image: { ...transform, fit: "cover", quality: 82, format: "auto" } },
      } as unknown as RequestInit);
      if (transformed.ok) return new Response(transformed.body, { headers: { "Content-Type": transformed.headers.get("Content-Type") ?? "image/webp", "Cache-Control": "public, max-age=86400" } });
    } catch (error) {
      console.warn("Cloudflare image transform failed; serving the R2 original.", error);
    }
  }

  const object = await env.IMAGES.get(key);
  if (!object) return new Response("Not found", { status: 404 });
  const headers = new Headers();
  object.writeHttpMetadata(headers);
  headers.set("ETag", object.httpEtag);
  headers.set("Cache-Control", "public, max-age=86400");
  return new Response(object.body, { headers });
}

async function handleQr(request: Request, env: Env) {
  const url = new URL(request.url);
  const match = url.pathname.match(/^\/qr\/@([a-z0-9-]+)\.svg$/);
  if (!match) return new Response("Not found", { status: 404 });
  const shop = await getShop(env, match[1]);
  if (!shop) return new Response("Not found", { status: 404 });
  const target = `${env.PUBLIC_BASE_URL || "https://pasher.shop"}/@${shop.slug}`;
  const qr = qrcode(0, "M");
  qr.addData(target);
  qr.make();
  return new Response(qr.createSvgTag({ cellSize: 5, margin: 2, scalable: true }), {
    headers: { "Content-Type": "image/svg+xml; charset=utf-8", "Cache-Control": "public, max-age=31536000, immutable", "Content-Disposition": `attachment; filename="${shop.slug}-qr.svg"` },
  });
}

async function handle(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method.toUpperCase();

  if (path === "/api/health") return json({ ok: true, app: "pasher-shop", runtime: "cloudflare-workers" }, 200, { "Cache-Control": "no-store" });
  if (path === "/index.html" && method === "GET") return redirect("/");
  if (isAssetPath(path)) return env.ASSETS.fetch(request);
  if (path.startsWith("/media/")) return serveMedia(request, env, path);
  if (path.startsWith("/image/")) return serveMedia(request, env, path);
  if (path.startsWith("/qr/")) return handleQr(request, env);

  if (path === "/api/shops" && method === "GET") {
    const nearby = await listShops(env, request, parseShopQuery(url));
    return json(nearby, 200, { "Cache-Control": "public, max-age=0, s-maxage=60" });
  }
  if (path === "/api/shops" && method === "POST") return handleShopJoin(request, env);
  if (path === "/api/orders" && method === "POST") return handleOrder(request, env);
  if (path === "/api/promotions" && method === "POST") return handlePromotion(request, env);

  if (path === "/" && method === "GET") {
    const query = parseShopQuery(url);
    const shops = await listShops(env, request, query);
    const nearbyShopIds = await listNearbyShopIds(env, query);
    const products = await listProducts(env, { shopIds: nearbyShopIds, page: 1, pageSize: 10 });
    return homePage(shops, products, query.district || "আপনার অবস্থান");
  }

  if (path === "/search" && method === "GET") {
    const query = parseShopQuery(url);
    const shops = await listShops(env, request, query);
    const nearbyShopIds = await listNearbyShopIds(env, query);
    const products = await listProducts(env, {
      shopIds: nearbyShopIds,
      query: url.searchParams.get("q")?.slice(0, 80),
      category: url.searchParams.get("category")?.slice(0, 60) || undefined,
      page: Math.max(1, Math.min(100, Number(url.searchParams.get("productPage")) || 1)),
      pageSize: 10,
    });
    return searchPage(shops, products, url);
  }

  if (path.startsWith("/@") && method === "GET") {
    const slug = decodeURIComponent(path.slice(2));
    if (!validSlug(slug)) return notFoundPage();
    const shop = await getShop(env, slug);
    if (!shop) return notFoundPage();
    const products = await listProducts(env, { shopId: shop.id, page: Math.max(1, Number(url.searchParams.get("page")) || 1), pageSize: 10 });
    return shopPage(shop, products, url.searchParams.get("ref") ?? "");
  }

  if (path.startsWith("/product/") && method === "GET") {
    const id = decodeURIComponent(path.slice("/product/".length));
    const product = await getProduct(env, id);
    if (!product) return notFoundPage();
    const shop = product.shop_slug ? await getShop(env, product.shop_slug) : null;
    return productPage(product, shop);
  }

  if (path === "/cart" && method === "GET") {
    const hasExplicitItems = url.searchParams.has("items") || url.searchParams.has("item");
    let items = hasExplicitItems ? allItemIds(url) : readCartCookie(request);
    const removeId = url.searchParams.get("remove");
    if (removeId) {
      const removeIndex = items.indexOf(removeId);
      if (removeIndex >= 0) items.splice(removeIndex, 1);
    }
    const addId = url.searchParams.get("add");
    if (addId && /^[a-z0-9-]{1,80}$/.test(addId) && items.length < 30) items.push(addId);
    const products = await getProductsByIds(env, items);
    const available = new Set(products.map((product) => product.id));
    items = items.filter((id) => available.has(id));
    return attachCartCookie(request, cartPage(products, items, url.searchParams.get("ref") ?? ""), items);
  }

  if (path === "/checkout" && method === "GET") {
    const items = allItemIds(url);
    const productRows = await getProductsByIds(env, items);
    const productMap = new Map(productRows.map((product) => [product.id, product]));
    const products = items.map((id) => productMap.get(id)).filter((product): product is Product => Boolean(product));
    return checkoutPage(products, url.searchParams.get("ref") ?? "");
  }

  if (path === "/order-confirmation" && method === "GET") {
    const token = url.searchParams.get("ref") ?? "";
    if (!/^[a-f0-9]{32}$/i.test(token)) return privateResponse(notFoundPage());
    const order = await env.DB.prepare("SELECT id, total_bdt, payment_method, delivery_option FROM orders WHERE public_token = ? LIMIT 1")
      .bind(token)
      .first<{ id: string; total_bdt: number; payment_method: string; delivery_option: string }>();
    return privateResponse(confirmationPage(order ?? null, url.searchParams.get("more") === "1"));
  }

  if (path === "/join-shop" && method === "GET") return joinShopPage();
  if (path === "/merchant" && method === "GET") return merchantPage();
  if (path === "/account" && method === "GET") return accountPage();

  const referralMatch = path.match(/^\/r\/([a-z0-9-]+)$/);
  if (referralMatch && method === "GET") {
    const slug = referralMatch[1];
    const shop = await getShop(env, slug);
    if (!shop) return notFoundPage();
    try { await env.DB.prepare("INSERT INTO referral_events (id, shop_slug, event_type) VALUES (?, ?, 'share')").bind(crypto.randomUUID(), slug).run(); } catch (error) { console.warn("Referral event write failed.", error); }
    return referralPage(shop);
  }

  return notFoundPage();
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    try {
      return await handle(request, env);
    } catch (error) {
      console.error("Pasher Shop request failed.", error);
      const url = new URL(request.url);
      if (url.pathname.startsWith("/api/")) return json({ error: "সাময়িক সমস্যা হয়েছে। আবার চেষ্টা করুন।" }, 500);
      return pageMessage("সাময়িক সমস্যা হয়েছে", "দয়া করে পেজটি refresh করে আবার চেষ্টা করুন।", "/", "হোমে ফিরুন");
    }
  },
};
