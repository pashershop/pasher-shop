# Pasher Shop — Cloudflare production setup

বর্তমান deliverable হলো Workers local Preview; `pasher.shop` এখনও deploy বা DNS-connect করা হয়নি। এই নির্দেশনা Cloudflare account-এর অনুমতি থাকা অবস্থায় চালাতে হবে। Live payment/account features সক্রিয় নয়।

## 1. D1 database ও R2 bucket

প্রকল্পের Cloudflare account-এ লগইন করুন, production D1 তৈরি করে পাওয়া UUID `wrangler.jsonc`-এর `d1_databases[0].database_id`-এ বসান, তারপর একই নামের R2 bucket তৈরি করুন:

```bash
pnpm wrangler login
pnpm wrangler d1 create pasher-shop
pnpm wrangler r2 bucket create pasher-shop-images
```

`database_id`-তে স্থানীয় placeholder `00000000-0000-0000-0000-000000000001` রেখে production deploy করবেন না। R2 bucket name `pasher-shop-images`-এর সঙ্গে config-এর নাম মিলতে হবে।

## 2. Remote D1 migration ও code deploy

Remote D1 ID বসানোর পর schema/index/seed migration চালান এবং production build/deploy করুন:

```bash
pnpm db:migrate:remote
pnpm check
pnpm deploy:cloudflare
```

Deployment-এর পর Cloudflare Workers-এ custom domain `pasher.shop` সংযুক্ত করুন, DNS/TLS status যাচাই করুন, তারপর `GET /api/health` থেকে `200` ও `runtime: cloudflare-workers` নিশ্চিত করুন। `PUBLIC_BASE_URL`-এ প্রকৃত canonical HTTPS origin রাখুন।

## 3. Generated banners ও R2 image resizing

বর্তমান generated hero/store banner URL-গুলো Manus Preview-এর Managed Storage path (`/manus-storage/...`)। এগুলো Cloudflare-only deployment-এর R2 objects নয়। Production-এ দোকানের image files `pasher-shop-images` bucket-এ upload করে প্রতিটি দোকানের `banner_url`-কে public Cloudflare asset URL অথবা `IMAGE_ORIGIN`-এর সঙ্গে সম্পর্কিত image route-এ আপডেট করতে হবে। `IMAGE_ORIGIN` হলো image-এ প্রবেশের public HTTPS custom domain—যেমন `img.pasher.shop`; এটি project secret নয়, কিন্তু Cloudflare DNS/zone অনুমতি লাগে।

Worker route `/image/thumb/{key}`, `/image/card/{key}` ও `/image/banner/{key}` preset-এ Cloudflare image transformation চায়; original `/media/{key}` থেকে পাওয়া যায়। Cloudflare account-এ Image Resizing/Transformations সুবিধা উপলব্ধ আছে কি না ও custom domain-origin configuration যাচাই করুন। Resize ব্যর্থ হলে route R2 original পরিবেশন করে।

## 4. Live ব্যবহারের আগে অপরিহার্য অসম্পূর্ণ কাজ

- Merchant/customer account provider, session, merchant ownership ও per-shop authorization স্থাপন করুন। বর্তমানে public shop registration `pending` record তৈরি করে; merchant dashboard, product editing/upload, moderation queue ও spam/rate-limit ব্যবস্থা নেই।
- bKash, Nagad, Rocket, Upay ও bank provider-এর merchant onboarding/API credentials, webhook signature verification, payment confirmation, refund/reconciliation যুক্ত করুন। Checkout এখন কেবল পেমেন্ট-পদ্ধতি পছন্দ রেকর্ড করে; কোনো টাকা কাটা হয় না। কোনো credential repository বা client code-এ লিখবেন না।
- Promotion request বর্তমানে `demo_pending`; বাস্তব টাকা নেওয়া, boost/ad delivery ও invoice accounting চালু নয়। Pasher Pass-এ share/order referral tracking আছে; coupon, loyalty reward ও abuse controls সম্পূর্ণ নয়।
- Local seed-এ demo shop/phone/data আছে। Production-এ publish করার আগে sample records ও contacts পর্যালোচনা/প্রতিস্থাপন করুন।
- Shop onboarding, map coordinates, image uploads, analytics, consent/privacy/retention, support contact এবং applicable local payment/business requirements live launch-এর আগে সম্পূর্ণ করুন।
