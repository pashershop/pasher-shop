// client/src/main.tsx
for (const locationButton of document.querySelectorAll("[data-use-location]")) {
  locationButton.addEventListener("click", () => {
    const form = locationButton.closest("form");
    const status = form?.querySelector("[data-location-status]");
    if (!form) return;
    if (!navigator.geolocation) {
      if (status) status.textContent = locationButton.hasAttribute("data-auto-submit") ? "\u098F\u0987 \u09AC\u09CD\u09B0\u09BE\u0989\u099C\u09BE\u09B0\u09C7 \u0985\u09AC\u09B8\u09CD\u09A5\u09BE\u09A8 \u09AA\u09BE\u0993\u09DF\u09BE \u09AF\u09BE\u099A\u09CD\u099B\u09C7 \u09A8\u09BE\u0964 \u099C\u09C7\u09B2\u09BE \u09AC\u09C7\u099B\u09C7 \u0996\u09C1\u0981\u099C\u09C1\u09A8\u0964" : "\u0985\u09AC\u09B8\u09CD\u09A5\u09BE\u09A8 \u09AA\u09BE\u0993\u09DF\u09BE \u09AF\u09BE\u099A\u09CD\u099B\u09C7 \u09A8\u09BE\u0964 \u09AE\u09BE\u09A8\u099A\u09BF\u09A4\u09CD\u09B0 \u09A5\u09C7\u0995\u09C7 \u0985\u0995\u09CD\u09B7\u09BE\u0982\u09B6 \u0993 \u09A6\u09CD\u09B0\u09BE\u0998\u09BF\u09AE\u09BE\u0982\u09B6 \u09B2\u09BF\u0996\u09C1\u09A8\u0964";
      return;
    }
    if (status) status.textContent = "\u0986\u09AA\u09A8\u09BE\u09B0 \u0985\u09AC\u09B8\u09CD\u09A5\u09BE\u09A8 \u0996\u09CB\u0981\u099C\u09BE \u09B9\u099A\u09CD\u099B\u09C7\u2026";
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => {
        const lat = form.querySelector('input[name="lat"], input[name="latitude"]');
        const lng = form.querySelector('input[name="lng"], input[name="longitude"]');
        if (lat) lat.value = String(coords.latitude);
        if (lng) lng.value = String(coords.longitude);
        if (locationButton.hasAttribute("data-auto-submit")) {
          const district = form.querySelector('select[name="district"]');
          if (district) district.value = "";
          form.requestSubmit();
        } else if (status) {
          status.textContent = "\u0985\u09AC\u09B8\u09CD\u09A5\u09BE\u09A8 \u09AF\u09CB\u0997 \u09B9\u09DF\u09C7\u099B\u09C7\u0964 \u09A6\u09CB\u0995\u09BE\u09A8\u09C7\u09B0 \u09A4\u09A5\u09CD\u09AF \u09AF\u09BE\u099A\u09BE\u0987 \u0995\u09B0\u09C7 \u099C\u09AE\u09BE \u09A6\u09BF\u09A8\u0964";
        }
      },
      () => {
        if (status) status.textContent = locationButton.hasAttribute("data-auto-submit") ? "\u0985\u09AC\u09B8\u09CD\u09A5\u09BE\u09A8 \u0985\u09A8\u09C1\u09AE\u09A4\u09BF \u09AA\u09BE\u0993\u09DF\u09BE \u09AF\u09BE\u09DF\u09A8\u09BF\u0964 \u099C\u09C7\u09B2\u09BE \u09AC\u09C7\u099B\u09C7 \u0996\u09C1\u0981\u099C\u09C1\u09A8\u0964" : "\u0985\u09AC\u09B8\u09CD\u09A5\u09BE\u09A8 \u0985\u09A8\u09C1\u09AE\u09A4\u09BF \u09AA\u09BE\u0993\u09DF\u09BE \u09AF\u09BE\u09DF\u09A8\u09BF\u0964 \u09AE\u09BE\u09A8\u099A\u09BF\u09A4\u09CD\u09B0 \u09A5\u09C7\u0995\u09C7 \u0985\u0995\u09CD\u09B7\u09BE\u0982\u09B6 \u0993 \u09A6\u09CD\u09B0\u09BE\u0998\u09BF\u09AE\u09BE\u0982\u09B6 \u09B2\u09BF\u0996\u09C1\u09A8\u0964";
      },
      { enableHighAccuracy: false, timeout: 6e3, maximumAge: 6e4 }
    );
  });
}
for (const button of document.querySelectorAll("[data-copy-link]")) {
  button.addEventListener("click", async () => {
    const value = button.dataset.copyLink ?? window.location.href;
    try {
      await navigator.clipboard.writeText(value);
      button.textContent = "\u09B2\u09BF\u0982\u0995 \u0995\u09AA\u09BF \u09B9\u09DF\u09C7\u099B\u09C7 \u2713";
    } catch {
      window.prompt("\u098F\u0987 \u09B2\u09BF\u0982\u0995\u099F\u09BF \u0995\u09AA\u09BF \u0995\u09B0\u09C1\u09A8:", value);
    }
  });
}
