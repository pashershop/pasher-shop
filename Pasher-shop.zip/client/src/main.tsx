for (const locationButton of document.querySelectorAll<HTMLButtonElement>("[data-use-location]")) {
  locationButton.addEventListener("click", () => {
    const form = locationButton.closest("form");
    const status = form?.querySelector<HTMLElement>("[data-location-status]");
    if (!form) return;
    if (!navigator.geolocation) {
      if (status) status.textContent = locationButton.hasAttribute("data-auto-submit")
        ? "এই ব্রাউজারে অবস্থান পাওয়া যাচ্ছে না। জেলা বেছে খুঁজুন।"
        : "অবস্থান পাওয়া যাচ্ছে না। মানচিত্র থেকে অক্ষাংশ ও দ্রাঘিমাংশ লিখুন।";
      return;
    }
    if (status) status.textContent = "আপনার অবস্থান খোঁজা হচ্ছে…";
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => {
        const lat = form.querySelector<HTMLInputElement>('input[name="lat"], input[name="latitude"]');
        const lng = form.querySelector<HTMLInputElement>('input[name="lng"], input[name="longitude"]');
        if (lat) lat.value = String(coords.latitude);
        if (lng) lng.value = String(coords.longitude);
        if (locationButton.hasAttribute("data-auto-submit")) {
          const district = form.querySelector<HTMLSelectElement>('select[name="district"]');
          if (district) district.value = "";
          form.requestSubmit();
        } else if (status) {
          status.textContent = "অবস্থান যোগ হয়েছে। দোকানের তথ্য যাচাই করে জমা দিন।";
        }
      },
      () => {
        if (status) status.textContent = locationButton.hasAttribute("data-auto-submit")
          ? "অবস্থান অনুমতি পাওয়া যায়নি। জেলা বেছে খুঁজুন।"
          : "অবস্থান অনুমতি পাওয়া যায়নি। মানচিত্র থেকে অক্ষাংশ ও দ্রাঘিমাংশ লিখুন।";
      },
      { enableHighAccuracy: false, timeout: 6000, maximumAge: 60000 },
    );
  });
}

for (const button of document.querySelectorAll<HTMLButtonElement>("[data-copy-link]")) {
  button.addEventListener("click", async () => {
    const value = button.dataset.copyLink ?? window.location.href;
    try {
      await navigator.clipboard.writeText(value);
      button.textContent = "লিংক কপি হয়েছে ✓";
    } catch {
      window.prompt("এই লিংকটি কপি করুন:", value);
    }
  });
}
