# Pasher Shop — বাস্তবায়ন পরিকল্পনা

## উদ্দেশ্য ও বাস্তবায়ন-সীমা

Pasher Shop হবে বাংলা-প্রথম লোকাল দোকান মার্কেটপ্লেস। গ্রাহক অ্যাকাউন্ট ছাড়াই দোকান ও পণ্য দেখতে, জেলা/এলাকা বেছে ৫ কিমির মধ্যে দোকান খুঁজতে, দোকানের WhatsApp/ফোনে যোগাযোগ করতে, pickup নির্বাচন করতে, অর্ডার করতে এবং বিকাশ, নগদ, রকেট, উপায়, ব্যাংক ট্রান্সফার বা pickup-এ পেমেন্টের পদ্ধতি বেছে নিতে পারবেন। চাইলে গ্রাহক অ্যাকাউন্ট তৈরি করতে পারবেন। দোকানদার বিনামূল্যে স্টোর পেজ তৈরি করবেন; দোকানের slug-ভিত্তিক URL `/@shopname` ও সেই URL-এর স্থায়ী QR থাকবে। দোকান পেজে ব্যানার, নাম, ধরন, ঠিকানা/মানচিত্র, সময়, যোগাযোগ ও পণ্য-দাম থাকবে। হোমপেজে জনপ্রিয় কাছের দোকান, ১০টি করে পেজিনেশন, ছাড়, প্রচারিত দোকান এবং lazy-loaded ছবি থাকবে।

### প্রস্তাবিত প্রযুক্তিগত পদ্ধতি

Cloudflare-কে মূল উৎপাদন স্থাপত্য ধরা হবে: TypeScript, React/Vite UI এবং Cloudflare Workers runtime; Workers-এ API ও route-rendering, D1-এ দোকান/পণ্য/অর্ডার/প্রমোশন তথ্য এবং R2-এ দোকান/পণ্যের ছবি। Cloudflare-এর Vite plugin স্থানীয় Workers runtime-এ চালানো ও D1/R2 binding অনুকরণের জন্য উপযোগী [1][4]। বর্তমান React/Vite কোডকে এই plugin-এ অভিযোজিত করে Preview-ও Workers runtime-এ চালানো হবে; বিদ্যমান Express/MySQL স্টার্টার অংশ marketplace-এর live data path হবে না। প্রাথমিকভাবে স্থানীয় D1/R2 bindings ও নমুনা ডেটা ব্যবহার হবে। Cloudflare-এ উৎপাদন deploy, `pasher.shop` DNS, প্রকৃত D1 database/R2 bucket binding এবং merchant payment credentials যুক্ত করার জন্য সংশ্লিষ্ট অ্যাকাউন্ট/অনুমতি প্রয়োজন; সেগুলো ছাড়া Preview-কে live production বা real-money payment বলে দেখানো হবে না।

D1 migration-এ slug-এর unique index, জেলা/ক্যাটাগরি/দোকানের অবস্থা/boost-ভিত্তিক composite index এবং order/shop join index থাকবে। জেলা ও ক্যাটাগরি ধরে candidate shops দ্রুত আনা হবে; ৫ কিমি নির্ভুলতা latitude/longitude bounding box-এর পরে Haversine দূরত্ব দিয়ে যাচাই হবে। D1 নথির পরামর্শমতো query-র `EXPLAIN QUERY PLAN` দিয়ে সূচক ব্যবহৃত হচ্ছে কি না দেখা হবে [2]। একই জেলার জনসাধারণের দোকান/ক্যাটালগ ফলাফল cache করা হবে; cache key-তে জেলা, ক্যাটাগরি ও পেজ থাকবে, কিন্তু ব্যক্তিগত অর্ডার বা customer-specific ফল cache হবে না। প্রতিটি তালিকা ১০টি করে দেখাবে।

ছবি R2-তে original হিসেবে থাকবে। আলাদা optimized-image route preset width/quality অনুযায়ী Worker `fetch(..., {cf: {image: ...}})` দিয়ে WebP/উপযুক্ত format পরিবেশন করবে; original ও transformed path আলাদা রাখা হবে, যাতে resize loop না হয় [3]। স্থানীয় Workers preview-এ image transformation-এর fidelity কম হতে পারে—প্রকৃত resize আচরণ deployment-এ যাচাই করতে হবে [3]।

JavaScript বন্ধ থাকলেও মূল দোকান-তালিকা, দোকান পেজ, পণ্য, দাম, সার্চ/ফিল্টার ও অর্ডারের প্রাথমিক ফর্ম ব্যবহারযোগ্য করতে Worker থেকে server-rendered HTML ও সাধারণ GET/POST form দেওয়া হবে। JavaScript কেবল cart feedback, modal, geolocation, share affordance এবং তাৎক্ষণিক UI উন্নত করবে। অনুমতি পেলে browser geolocation ব্যবহার হবে; না হলে এলাকা/জেলা বেছে নেওয়া যাবে। মানচিত্রে দোকানের স্থান এবং directions link দেখানো হবে।

### পণ্য ও আয়-ফিচার

দোকান যোগ করা বিনামূল্যে থাকবে। দোকানদার পেইজ boost (যেমন ৭/৩০ দিনের প্যাকেজ), ছাড়যুক্ত পণ্যের বিজ্ঞাপন, হোমপেজে প্রচার, এবং বিক্রয়/দর্শক analytics, verified profile ও উন্নত পণ্য-তালিকার মতো ঐচ্ছিক paid সুবিধার পরিকল্পনা/ড্যাশবোর্ড দেখতে পারবেন। ভাইরাল বৃদ্ধির মূল ফিচার হবে **Pasher Pass**: দোকান/অফারের QR বা share link পাঠিয়ে নতুন ক্রেতা আনলে referral coupon/loyalty stamp; পুরস্কার ও ব্যবহার-সীমা সার্ভারে রেকর্ড হবে এবং অপব্যবহার-নিয়ন্ত্রণ থাকবে। গ্রাহকের অ্যাকাউন্ট ঐচ্ছিক; দোকান পরিচালনার জন্য merchant account লাগবে।

Checkout-এ গ্রাহক উল্লিখিত সব স্থানীয় পেমেন্ট পদ্ধতি বেছে নিতে পারবেন এবং pickup/Pay-at-pickup-ও পাবেন। কিন্তু বিকাশ/নগদ/রকেট/উপায় বা ব্যাংকের real-money checkout চালাতে merchant onboarding, সংশ্লিষ্ট provider-এর API/merchant credentials, webhook এবং production অনুমতি লাগবে। সেগুলো না পাওয়া পর্যন্ত checkout হবে পরীক্ষামূলক/নির্দেশনামূলক—কোনো টাকা নেওয়া হবে না। একইভাবে boost/ad UI ও order flow Preview-তে প্রদর্শনযোগ্য থাকবে; বাস্তব billing এবং fulfilment credentials-পরবর্তী ধাপ।

## প্রকল্প কাঠামো

- `worker/index.ts`, `worker/data.ts`, `worker/html.ts`, `worker/types.ts`: TypeScript Cloudflare Worker routes, D1 queries/cache, server-rendered HTML, model contracts, guest orders, promotion request, QR/share/referral ও R2 image routes.
- `client/src/main.tsx`: no-JS SSR-এ progressive enhancement (geolocation/share affordance); `client/public/styles.css`, `favicon.svg`, `enhance.js`, `manus-routes.json`: responsive presentation, icon, minimal browser script ও route declaration.
- `migrations/`: D1 schema, indexes, demo seed data ও incremental migration.
- `wrangler.jsonc`: Workers runtime, D1/R2 bindings, static assets ও public-origin settings; production resource ID/domain পরে Cloudflare account-এ বসবে.
- `TODO.md` ও `CLOUDFLARE_SETUP_BN.md`: feature status এবং account/resource/production handoff.

`/merchant`-এ pricing ও promotion-request Preview আছে; sign-in-সুরক্ষিত merchant dashboard পরে auth provider ও shop-owner controls যুক্ত করে তৈরি করতে হবে।

প্রধান page route হবে `/`, `/@shopSlug`, `/search`, `/product/:productId`, `/cart`, `/checkout`, `/join-shop`, `/merchant`, `/account`, `/order-confirmation` ও `/r/:shopSlug`; `/manus-routes.json`-এ source-এর সব page route প্রতিফলিত হবে। `/qr/...svg` image asset route, page route নয়।

## ডিজাইন

তিনটি বিকল্প শৈলী—সম্ভাব্যতা নমুনা: 0.068, 0.030, 0.094:

1. **বাংলা আধুনিক বাজার-সম্পাদকীয়** (0.068) — উষ্ণ, প্রাণবন্ত বাজারের রঙ ও পরিচ্ছন্ন editorial typography.
2. **নিরপেক্ষ টেক-ডিরেক্টরি** (0.030) — ঠান্ডা নীল-সাদা, ঘন তথ্য ও utility-first মানচিত্র.
3. **রঙিন পাড়া-পোস্টার** (0.094) — লোকাল signage-প্রেরিত সাহসী রঙ ও খেলাচ্ছলে প্রচার.

**নির্বাচিত ধারা: বাংলা আধুনিক বাজার-সম্পাদকীয়।**

- **Design Movement:** সমসাময়িক বাংলা editorial commerce; পরিচিত পাড়ার উষ্ণতা, ডিজিটাল সার্ভিসের শৃঙ্খলা.
- **Core Principles:** দ্রুত স্ক্যানযোগ্য তথ্য; দোকান ও পণ্যের বিশ্বাসযোগ্য পরিচয়; ছোট পর্দায় সহজ হাতে-ব্যবহার; প্রচার ও স্বাভাবিক তালিকার স্বচ্ছ পার্থক্য.
- **Color Philosophy:** হালকা চাল/কাগজ-রঙের পটভূমি, বাজার-সবুজের আস্থা, পেয়ারা/টমেটো-লালের অফার হাইলাইট এবং কালচে কালি টেক্সট. নিজস্ব ব্র্যান্ড রং `#16845B`.
- **Layout Paradigm:** editorial hero ও search দিয়ে শুরু, পরে horizontal category chips এবং কাছের দোকান/পণ্যের ধারাবাহিক feed; মোবাইলে একহাতে ব্যবহারযোগ্য compact search ও category navigation—সব কিছু একরকম card-grid নয়.
- **Signature Elements:** লোকেশন-পিনসহ দূরত্ব chip; QR-অনুপ্রাণিত ক্ষুদ্র বর্গাকার brand motif; মূল্য ও ছাড়ে contrasting market-stamp.
- **Interaction Philosophy:** প্রথমে browse ও যোগাযোগ, তারপর অর্ডার; অনুমতি ছাড়া location নয়; URL/share/সাধারণ form সবসময় কাজে লাগবে.
- **Animation:** সীমিত, 140–220 ms; filter chip, cart count ও accordion-এ মৃদু transition. Reduced-motion-এ animation বন্ধ; content লুকিয়ে রাখে এমন entrance animation নয়.
- **Typography System:** Bengali system-font stack-এ Noto Sans Bengali অগ্রাধিকার; fallback Nirmala UI/system sans, দূরবর্তী font download নয়. শিরোনাম 28–40 px, সেকশন 20–24 px, body 14–16 px, price/দূরত্বে medium-bold.
- **Brand Essence:** “পাশের দোকান, এখন হাতের কাছে”—নিজ এলাকার ক্রেতা ও স্বাধীন দোকানদারকে সরাসরি যুক্ত করে; personality: আপন, দ্রুত, নির্ভরযোগ্য.
- **Brand Voice:** সংক্ষিপ্ত ও স্থানীয়; আহ্বান জোর করে নয়, কাজের তথ্য আগে. উদাহরণ: “আপনার ৫ কিমির ভেতর কী আছে?” এবং “দোকান যোগ করুন—খরচ নেই.”
- **Wordmark & Logo:** দুইটি সংলগ্ন দোকান-ছাদ/লোকেশন-পিন দিয়ে তৈরি সরল `P`-আকৃতির mark; পাশে বাংলা নাম “পাশের শপ” ও ক্ষুদ্র Latin “Pasher Shop”.
- **Signature Brand Color:** বাজার-সবুজ `#16845B`.

## প্রয়োজনীয় বহিঃসেবা ও সীমা

Cloudflare Workers Vite plugin, D1 index ও image-resizing আচরণ অফিসিয়াল নথির ভিত্তিতে পরিকল্পিত [1][2][3]। স্থানীয় D1/R2 resources Workers development-এ অনুকরণ করা যায় [4]। production deploy ও `pasher.shop` domain যোগ করতে Cloudflare account access লাগবে। বাস্তব gateway payment-এর জন্য প্রতিটি provider-এর merchant credentials/approval লাগবে; সেগুলো secure input দিয়ে যুক্ত না হওয়া পর্যন্ত কোনো real transaction হবে না।

### References

[1]: https://developers.cloudflare.com/workers/vite-plugin/ "Cloudflare Workers Vite plugin"
[2]: https://developers.cloudflare.com/d1/best-practices/use-indexes/ "Cloudflare D1 index best practices"
[3]: https://developers.cloudflare.com/images/optimization/transformations/transform-via-workers/ "Cloudflare image transformations via Workers"
[4]: https://developers.cloudflare.com/workers/local-development/local-data/ "Cloudflare local development data"
