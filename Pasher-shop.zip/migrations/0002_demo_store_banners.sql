UPDATE shops SET banner_url = '/manus-storage/async-images/GabSvLNDAzYSPuWRlmXGfN/image-1.webp' WHERE slug = 'mitalifruits';
UPDATE shops SET banner_url = '/manus-storage/async-images/GabSvLNDAzYSPuWRlmXGfN/image-2.webp' WHERE slug = 'noorbazar';
UPDATE shops SET banner_url = '/manus-storage/async-images/GabSvLNDAzYSPuWRlmXGfN/image-3.webp' WHERE slug = 'priyopustak';
UPDATE shops SET banner_url = '/manus-storage/async-images/GabSvLNDAzYSPuWRlmXGfN/image-4.webp' WHERE slug = 'uttarafashion';
