PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS shops (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  district TEXT NOT NULL,
  area TEXT NOT NULL,
  address TEXT NOT NULL,
  latitude REAL NOT NULL,
  longitude REAL NOT NULL,
  phone TEXT NOT NULL,
  whatsapp TEXT NOT NULL,
  hours TEXT NOT NULL DEFAULT 'সকাল ৯টা–রাত ১০টা',
  description TEXT NOT NULL DEFAULT '',
  banner_url TEXT,
  rating REAL NOT NULL DEFAULT 0,
  rating_count INTEGER NOT NULL DEFAULT 0,
  is_boosted INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'paused')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_shops_slug ON shops(slug);
CREATE INDEX IF NOT EXISTS idx_shops_district_status_geo ON shops(district, status, latitude, longitude);
CREATE INDEX IF NOT EXISTS idx_shops_district_category_boost ON shops(district, category, status, is_boosted, rating);

CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  shop_id TEXT NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  price_bdt INTEGER NOT NULL CHECK (price_bdt >= 0),
  old_price_bdt INTEGER CHECK (old_price_bdt IS NULL OR old_price_bdt >= 0),
  unit TEXT NOT NULL DEFAULT 'টি',
  image_key TEXT,
  emoji TEXT NOT NULL DEFAULT '🛍️',
  in_stock INTEGER NOT NULL DEFAULT 1,
  is_featured INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_products_shop_stock ON products(shop_id, in_stock, is_featured, created_at);
CREATE INDEX IF NOT EXISTS idx_products_category_stock ON products(category, in_stock, price_bdt);

CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  public_token TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  delivery_option TEXT NOT NULL CHECK (delivery_option IN ('pickup', 'delivery')),
  delivery_address TEXT NOT NULL DEFAULT '',
  payment_method TEXT NOT NULL CHECK (payment_method IN ('bkash', 'nagad', 'rocket', 'upay', 'bank', 'pickup')),
  payment_status TEXT NOT NULL DEFAULT 'awaiting_merchant_setup',
  referral_slug TEXT,
  total_bdt INTEGER NOT NULL CHECK (total_bdt >= 0),
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_phone_created ON orders(customer_phone, created_at DESC);

CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id TEXT NOT NULL REFERENCES products(id),
  product_title TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity BETWEEN 1 AND 99),
  unit_price_bdt INTEGER NOT NULL CHECK (unit_price_bdt >= 0)
);

CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_product ON order_items(product_id);

CREATE TABLE IF NOT EXISTS promotion_requests (
  id TEXT PRIMARY KEY,
  shop_slug TEXT NOT NULL,
  promotion_type TEXT NOT NULL CHECK (promotion_type IN ('boost', 'discount_ad', 'analytics', 'verified')),
  package_code TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'demo_pending',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_promotion_shop_status_created ON promotion_requests(shop_slug, status, created_at DESC);

CREATE TABLE IF NOT EXISTS referral_events (
  id TEXT PRIMARY KEY,
  shop_slug TEXT NOT NULL,
  order_id TEXT REFERENCES orders(id),
  event_type TEXT NOT NULL CHECK (event_type IN ('share', 'order')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_referral_shop_type_created ON referral_events(shop_slug, event_type, created_at DESC);

INSERT OR IGNORE INTO shops (id, slug, name, category, district, area, address, latitude, longitude, phone, whatsapp, hours, description, banner_url, rating, rating_count, is_boosted, status) VALUES
('shop-rahim', 'rahimstore', 'রহিম স্টোর', 'মুদি ও নিত্যপণ্য', 'ঢাকা', 'ধানমন্ডি', 'রোড ৮, ধানমন্ডি, ঢাকা', 23.7465, 90.3765, '+8801712345678', '8801712345678', 'সকাল ৮টা–রাত ১০টা', 'আপনার প্রতিদিনের বাজার—ভালো পণ্য, সঠিক দাম, একদম পাড়ার পাশে।', '/manus-storage/async-images/T72t3EiJwgjtQCyPtYGdqs/image-2.webp', 4.9, 128, 1, 'active'),
('shop-mitali', 'mitalifruits', 'মিতালী ফল ঘর', 'ফল ও সবজি', 'ঢাকা', 'ধানমন্ডি', 'সাতমসজিদ রোড, ধানমন্ডি, ঢাকা', 23.7408, 90.3725, '+8801811223344', '8801811223344', 'সকাল ৭টা–রাত ৯টা', 'মৌসুমি ফল ও টাটকা সবজি—প্রতিদিন সকালে নতুন করে আসে।', NULL, 4.8, 96, 0, 'active'),
('shop-noor', 'noorbazar', 'নূর বাজার', 'মুদি ও নিত্যপণ্য', 'ঢাকা', 'কলাবাগান', 'গ্রিন রোড, কলাবাগান, ঢাকা', 23.7490, 90.3860, '+8801911223344', '8801911223344', 'সকাল ৮টা–রাত ১১টা', 'পাড়ার পরিচিত দোকান, দরকারি সবকিছু সহজে পান।', NULL, 4.7, 74, 0, 'active'),
('shop-priyo', 'priyopustak', 'প্রিয় বইঘর', 'বই ও স্টেশনারি', 'ঢাকা', 'ধানমন্ডি', 'ধানমন্ডি ২৭, ঢাকা', 23.7500, 90.3780, '+8801611223344', '8801611223344', 'সকাল ১০টা–রাত ৯টা', 'পাঠ্যবই, গল্পের বই আর স্কুল-অফিসের স্টেশনারি।', NULL, 4.9, 53, 0, 'active'),
('shop-uttara', 'uttarafashion', 'সুরমা ফ্যাশন', 'পোশাক', 'ঢাকা', 'উত্তরা', 'সেক্টর ৭, উত্তরা, ঢাকা', 23.8720, 90.3980, '+8801711998877', '8801711998877', 'সকাল ১০টা–রাত ১০টা', 'দৈনন্দিন পোশাক ও স্থানীয় ডিজাইনের কালেকশন।', NULL, 4.6, 41, 0, 'active');

INSERT OR IGNORE INTO products (id, shop_id, title, category, description, price_bdt, old_price_bdt, unit, emoji, in_stock, is_featured) VALUES
('p-rice', 'shop-rahim', 'মিনিকেট চাল', 'মুদি', 'পরিষ্কার, ঝরঝরে চাল; প্রতিদিনের রান্নার জন্য।', 385, 420, '৫ কেজি', '🍚', 1, 1),
('p-oil', 'shop-rahim', 'সয়াবিন তেল', 'মুদি', 'পরিবারের রান্নার জন্য নির্ভরযোগ্য মানের তেল।', 178, NULL, '১ লিটার', '🫗', 1, 1),
('p-eggs', 'shop-rahim', 'ফার্মের ডিম', 'মুদি', 'তাজা ফার্মের ডিম, প্রতিদিনের সংগ্রহ।', 145, NULL, 'ডজন', '🥚', 1, 0),
('p-milk', 'shop-rahim', 'পাস্তুরিত দুধ', 'মুদি', 'ফ্রেশ পাস্তুরিত দুধ।', 95, 105, '১ লিটার', '🥛', 1, 1),
('p-mango', 'shop-mitali', 'ল্যাংড়া আম', 'ফল', 'মৌসুমি মিষ্টি ল্যাংড়া আম।', 160, 190, 'কেজি', '🥭', 1, 1),
('p-banana', 'shop-mitali', 'সাগর কলা', 'ফল', 'পাকা, মিষ্টি সাগর কলা।', 75, NULL, 'ডজন', '🍌', 1, 0),
('p-tomato', 'shop-mitali', 'দেশি টমেটো', 'সবজি', 'টাটকা দেশি টমেটো।', 55, 65, 'কেজি', '🍅', 1, 1),
('p-potato', 'shop-noor', 'দেশি আলু', 'সবজি', 'বাছাই করা দেশি আলু।', 35, NULL, 'কেজি', '🥔', 1, 0),
('p-notebook', 'shop-priyo', 'হার্ডকভার নোটবুক', 'স্টেশনারি', 'কলেজ/অফিস নোটের জন্য ১০০ পাতার নোটবুক।', 90, NULL, 'টি', '📒', 1, 1),
('p-pen', 'shop-priyo', 'বলপেন সেট', 'স্টেশনারি', 'নীল কালির মসৃণ বলপেন।', 30, NULL, '৩টি', '🖊️', 1, 0);
