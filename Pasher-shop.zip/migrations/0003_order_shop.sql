ALTER TABLE orders ADD COLUMN shop_id TEXT REFERENCES shops(id);
CREATE INDEX IF NOT EXISTS idx_orders_shop_created ON orders(shop_id, created_at DESC);
