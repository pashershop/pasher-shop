# Pasher Shop — TODO

এই তালিকার status Preview-তে যাচাইকৃত আচরণ ও অনিষ্পন্ন production dependency অনুযায়ী। “Complete (Preview)” live launch, moderation, account বা real-money payment বোঝায় না।

## দোকানের আলাদা পেজ, স্থায়ী QR এবং তথ্য

**Status: Partial — generated artwork pending**

- প্রত্যেক দোকানের আলাদা পেজ থাকবে; উদাহরণ: `pasher.shop/@rahimstore` এবং `pasher.shop/@rahimshop`। Preview-তে `/@shopSlug` route কাজ করে এবং seed করা দোকানের পেজ দেখায়।
- দোকানের লিংকের একটি স্থায়ী QR code থাকবে; দোকান পেজ থেকে একই canonical URL-ভিত্তিক SVG QR download করা যায়। QR target `PUBLIC_BASE_URL`-এর ওপর নির্ভরশীল; `pasher.shop` DNS/production এখনও connect হয়নি।
- দোকানের পেজে ব্যানার ইমেজ, দোকানের নাম, ক্যাটাগরি, দোকানের লোকেশন/মানচিত্র, ঠিকানা/যোগাযোগ, পণ্যের তালিকা এবং পণ্যের দাম থাকবে। নতুন দোকানের signup-এ Dhanmondi default না দিয়ে merchant-এর exact latitude/longitude আবশ্যক; geolocation বা manual coordinates দিয়ে দিতে হবে।
- পেজে WhatsApp-এ কথা বলা ও ফোন নম্বরে কল করার সরাসরি সুবিধা থাকবে।
- Rahimসহ demo store-গুলোতে distinct banner URL wiring আছে; চারটি custom banner image generation background-এ চলমান, তাই শেষ artwork/asset availability এখনো pending।

## কাছের দোকান, হোমপেজ এবং তালিকা

**Status: Complete (Preview)**

- কাস্টমার খুব সহজে কাছের (৫ কি.মি.) দোকান খুঁজে পাবে; browser location নিলে coordinates দিয়ে district filter বাদ দিয়ে ওই অবস্থানের সঠিক radius খোঁজা হবে। Permission না দিলে উপলব্ধ district center/এলাকা দিয়ে বিকল্প খোঁজা যাবে; UI-তে নির্বাচিত district বা “আপনার অবস্থান” দেখাতে হবে, ভুল Dhanmondi label নয়।
- হোমপেজে জনপ্রিয় কাছের দোকানগুলো দেখা যাবে; boosted shop, rating ও rating-count-কে অগ্রাধিকার দিয়ে দূরত্ব tie-break হিসেবে ব্যবহার করা হবে।
- পণ্য ও দোকানের তালিকা ১০টি করে paginated হবে; search page-এ shops-এর `shopPage` ও products-এর `productPage` আলাদা থাকবে, যাতে একটি তালিকার page change অন্যটিকে না সরায়।
- Product-title search-এ দোকানের নাম না মিললেও ৫ কিমির eligible দোকানের পণ্য খুঁজে পাওয়া যাবে।
- একই জেলার মধ্যে জনসাধারণের দোকান/ক্যাটালগ ফল cache হবে; ব্যক্তিগত/অর্ডার-নির্ভর ফল cache হবে না। GPS coordinates-এ exact radius result district-default cache-এ রাখা হবে না।
- Lazy-load system থাকবে, যেন scroll করলে নিচের ছবি/তালিকা লোড হয়.
- JavaScript বন্ধ থাকলেও মূল browse, দোকান/পণ্য দেখা, search/filter, guest cart, shop registration ও অর্ডারের প্রাথমিক form ব্যবহারযোগ্য থাকবে; JavaScript শুধু progressive enhancement করবে। Guest cart cookie server-side; HTTPS-এ `SameSite=None; Secure`, plain-HTTP local development-এ আলাদা cookie setting।

## পণ্য, যোগাযোগ, guest order ও পেমেন্ট-পদ্ধতি

**Status: Partial**

- কাস্টমার পণ্যসামগ্রী দেখতে ও দাম জানতে পারবে, WhatsApp-এ কথা বলতে পারবে এবং ফোন নম্বরে কল করতে পারবে।
- কাস্টমার অর্ডার করতে পারবে; প্রয়োজনে দোকানে গিয়ে পণ্য নিতে পারবে। Preview-তে D1-এ test order ও order items লেখা হয়। Multi-shop cart-এ প্রত্যেক দোকানের জন্য আলাদা checkout/order group থাকবে; একটি shop-এর order-এ অন্য shop-এর item মেশানো যাবে না, এবং order row-তে shop id থাকবে। একটি দোকানের order দিলে অন্যান্য দোকানের bag items ব্যাগে থাকবে।
- কাস্টমার বিকাশ, নগদ, রকেট, উপায় ও ব্যাংক অ্যাকাউন্টের পেমেন্ট-পদ্ধতি বেছে নিতে পারবে। Pickup/Pay-at-pickup বিকল্পও দেখানো হবে। পেমেন্ট method order-এ সংরক্ষিত হয়, কিন্তু কোনো gateway/real-money transaction চালু নয়।
- কাস্টমারের account খোলা বাধ্যতামূলক নয়; চাইলে customer account তৈরি করার পথ থাকবে। Guest checkout আছে; customer registration/sign-in এখনো functional নয়।
- Preview checkout/order flow পরীক্ষামূলক; merchant onboarding, provider credentials, webhook ও production approval না পাওয়া পর্যন্ত কোনো real-money payment হবে না। Confirmation page-এ টাকা না কাটার কথা স্পষ্ট লেখা আছে।

## বিনামূল্যের দোকান নিবন্ধন, merchant promotion, Pasher Pass ও abuse controls

**Status: Partial**

- দোকান যুক্ত করতে কোনো টাকা লাগবে না; দোকানদার বিনামূল্যে দোকান পেজ তৈরি করার form পাবেন। Preview form exact coordinates-সহ তথ্য moderation-এর জন্য `pending` status-এ রাখে; owner sign-in/verification-এর আগে public profile/management চালু নয়।
- দোকানদার তার দোকান পেইজ সবার সামনে দেখানোর জন্য paid boost করতে পারবে। Preview-তে boost request path ও demo pricing আছে; paid billing/boost fulfilment এখনো নয়।
- কোনো পণ্যে ছাড় থাকলে দোকানদার বিজ্ঞাপন দিতে পারবে। Preview-তে বিজ্ঞাপন/paid সুবিধার demo package দেখা যায়; বাস্তব billing চালু হবে payment integration-এর পর।
- বিক্রয়/দর্শক analytics, verified profile ও উন্নত product listing-এর মতো অতিরিক্ত বিক্রয়যোগ্য সুবিধা থাকবে; এখন এগুলো feature/pricing proposal, কার্যকর merchant tools নয়।
- Pasher Pass referral/QR/share link দিয়ে নতুন customer আমন্ত্রণ, coupon/loyalty stamp ও referral reward দেখাবে; ব্যবহারসীমা/record server-side হবে। Preview-তে tracked share link ও order referral event আছে; coupon issuance, loyalty stamps, reward redemption ও abuse controls বাকি।
- Merchant sign-in/ownership authorization নেই; promotion request এখনও demo-only. Rate limiting, spam prevention, moderation queue, verified ownership ও merchant order management production-এর আগে অপরিহার্য। Cross-site form writes reject করা হয়, কিন্তু এটি পূর্ণ abuse/rate-limit system নয়।
- দোকান পরিচালনার জন্য merchant account লাগবে; accountless browsing ও guest order গ্রাহকের default থাকবে। Merchant/customer authentication ও owner controls এখনো implement/configure করা হয়নি।

## Cloudflare runtime, D1/R2 ও TypeScript architecture

**Status: Partial**

- Website TypeScript কোডে হবে এবং Cloudflare Workers Edge Runtime-এর জন্য সাজানো হবে। Preview-তে Cloudflare Vite plugin/Workers runtime চালু।
- দোকান, পণ্য, অর্ডার ও প্রচার-তথ্যের জন্য Cloudflare D1 migration/index থাকবে; query plan-এ index ব্যবহারের আচরণ যাচাই করা হবে। Local D1 schema/banner/order migrations apply করা হয়েছে; production D1 binding নেই।
- Cloudflare R2-তে original shop/product image থাকবে; Worker দিয়ে image resize/preset পরিবেশন হবে। R2 binding/resize route আছে; Preview-র generated banners এখনো Manus Managed Storage-এ, production R2 bucket-এ স্থানান্তর বাকি।
- District/category/page key-ভিত্তিক district cache, ১০-item pagination এবং scroll-এ lazy image loading থাকবে.
- Local Preview-তে Workers runtime এবং local D1/R2 emulation ব্যবহৃত হবে। `pasher.shop` production deployment, DNS, বাস্তব D1/R2 resource binding, R2 image upload এবং real payment provider integration credentials যোগ না হওয়া পর্যন্ত অসম্পূর্ণ থাকবে।

## বাংলা-প্রথম ব্র্যান্ড, ব্যবহারযোগ্যতা ও page routes

**Status: Partial — artwork generation continues**

- বাংলা-প্রথম, responsive, দ্রুত ও পেশাদার storefront হবে; নির্বাচিত ধারা বাংলা আধুনিক বাজার-সম্পাদকীয় এবং নিজস্ব brand green `#16845B`।
- Reduced-motion support, দ্রুত স্ক্যানযোগ্য দাম/দূরত্ব, মোবাইলে ব্যবহারযোগ্য search ও category filter থাকবে।
- `/`, `/@shopSlug`, `/search`, `/product/:productId`, `/cart`, `/checkout`, `/join-shop`, `/merchant`, `/account`, `/order-confirmation` এবং `/r/:shopSlug` page routes source-এর সঙ্গে synchronized `/manus-routes.json`-এ থাকবে; APIs/assets/404-only route manifest-এ থাকবে না।
- Custom marketplace hero এবং পৃথক shop-banner artwork ব্যবহার হবে। Hero ও Rahim store banner wired; আরও চারটি দোকানের category-specific banner generation background-এ চলছে—completed image যাচাই না করা পর্যন্ত artwork completion ধরা হবে না।
